
'use client';

import { Button } from '@/components/ui/button';
import { Languages } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function LanguageSwitcher() {
  const { language: currentLanguage, setLanguage: onLanguageChange } = useLanguage();
  return (
    <div className="flex items-center gap-2">
      <Languages className="h-4 w-4 text-red-600" />
      <div className="flex border border-gray-600 rounded-md overflow-hidden">
        <Button
          variant={currentLanguage === 'en' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onLanguageChange('en')}
          className="px-3 py-1 text-xs rounded-none bg-transparent hover:bg-red-600 hover:text-white border-none"
        >
          EN
        </Button>
        <Button
          variant={currentLanguage === 'fr' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onLanguageChange('fr')}
          className="px-3 py-1 text-xs rounded-none bg-transparent hover:bg-red-600 hover:text-white border-none"
        >
          FR
        </Button>
      </div>
    </div>
  );
}
