
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Phone, Menu, X } from 'lucide-react';
import LanguageSwitcher from '@/components/language-switcher';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Header() {
  const { language, setLanguage } = useLanguage();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const t = (key: string) => getTranslation(language, key);

  const navigation = [
    { name: t('home'), href: '/' },
    { name: t('about'), href: '/about' },
    { name: t('services'), href: '/services' },
    { name: t('serviceArea'), href: '/service-area' },
    { name: t('testimonials'), href: '/testimonials' },
    { name: t('contact'), href: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-black/90 backdrop-blur-sm border-b border-gray-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-md overflow-hidden">
              <Image
                src="/logo.jpg"
                alt="GB Mobile Logo"
                fill
                className="object-cover"
                sizes="48px"
              />
            </div>
            <span className="text-xl font-bold text-white">GB Mobile</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navigation.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-gray-300 hover:text-red-500 transition-colors font-medium"
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            
            {/* Call button */}
            <Button 
              asChild
              className="hidden sm:flex bg-orange-500 hover:bg-orange-600 text-white font-medium"
            >
              <a href="tel:450-613-3778" className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                {language === 'en' ? 'Call Now' : 'Appeler maintenant'}
              </a>
            </Button>

            {/* Book Now button */}
            <Button 
              asChild
              className="hidden md:flex bg-orange-500 hover:bg-orange-600 text-white font-medium"
            >
              <Link href="/contact">
                {language === 'en' ? 'Book Appointment' : 'Prendre rendez-vous'}
              </Link>
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-800 py-4">
            <nav className="flex flex-col gap-4">
              {navigation.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-gray-300 hover:text-red-500 transition-colors font-medium py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <div className="flex flex-col gap-2 pt-4 border-t border-gray-800">
                <Button 
                  asChild
                  className="bg-red-600 hover:bg-red-700 text-white justify-center"
                >
                  <a href="tel:450-613-3778" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    {t('callNow')}
                  </a>
                </Button>
                <Button 
                  asChild
                  variant="outline"
                  className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white justify-center"
                >
                  <Link href="/contact">
                    {t('bookNow')}
                  </Link>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
