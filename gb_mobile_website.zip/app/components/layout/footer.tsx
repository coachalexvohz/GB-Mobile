
'use client';

import Link from 'next/link';
import { Phone, Mail } from 'lucide-react';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Footer() {
  const { language } = useLanguage(); // This should sync with global language state
  
  const t = (key: string) => getTranslation(language, key);

  return (
    <footer className="bg-black border-t border-gray-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">GB Mobile</h3>
            <p className="text-gray-400 mb-4">
              {language === 'en' 
                ? 'Professional mobile automotive repair service serving Lachute and surrounding areas since 2021.'
                : 'Service de mécanique mobile professionnel desservant Lachute et les environs depuis 2021.'
              }
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/services" className="text-gray-400 hover:text-red-500 transition-colors">
                {t('services')}
              </Link>
              <Link href="/service-area" className="text-gray-400 hover:text-red-500 transition-colors">
                {t('serviceArea')}
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-red-500 transition-colors">
                {t('contact')}
              </Link>
            </nav>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">{t('contactInfo')}</h4>
            <div className="flex flex-col gap-3">
              <a href="tel:450-613-3778" className="flex items-center gap-2 text-gray-400 hover:text-red-500 transition-colors">
                <Phone className="h-4 w-4" />
                450-613-3778
              </a>
              <a href="mailto:gb_mobile99@outlook.com" className="flex items-center gap-2 text-gray-400 hover:text-red-500 transition-colors">
                <Mail className="h-4 w-4" />
                gb_mobile99@outlook.com
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 GB Mobile. {language === 'en' ? 'All rights reserved.' : 'Tous droits réservés.'}
          </p>
        </div>
      </div>
    </footer>
  );
}
