
'use client';

import Link from 'next/link';
import Image from 'next/image';
import { 
  Car, 
  Wrench, 
  Gauge, 
  Clock,
  CheckCircle,
  Phone,
  Settings,
  ArrowRight,
  Shield,
  Zap
} from 'lucide-react';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ServicesPage() {
  const { language } = useLanguage();
  
  const t = (key: string) => getTranslation(language, key);

  const services = [
    {
      id: 'oil-change',
      title: t('oilChange'),
      frenchTitle: 'Changement d\'huile',
      price: '$90 CAD',
      icon: Car,
      image: '/images/oil-change.png',
      description: t('oilChangeDesc'),
      features: language === 'en' ? [
        'Complete oil change service',
        'Oil filter replacement',
        'Multi-point inspection',
        'Fluid level checks',
        'Service reminder sticker'
      ] : [
        'Service complet de changement d\'huile',
        'Remplacement du filtre à huile',
        'Inspection multipoints',
        'Vérification des niveaux de fluides',
        'Collant de rappel de service'
      ],
      duration: language === 'en' ? '30-45 minutes' : '30-45 minutes'
    },
    {
      id: 'tire-change',
      title: t('tireChange'),
      frenchTitle: 'Changement de pneus',
      price: '$60-100 CAD',
      icon: Car,
      image: '/images/tire-change.png',
      description: t('tireChangeDesc'),
      features: language === 'en' ? [
        'Seasonal tire changes',
        'Tire mounting and demounting',
        'Wheel balancing available',
        'Tire pressure adjustment',
        'Visual tire inspection'
      ] : [
        'Changements saisonniers de pneus',
        'Montage et démontage des pneus',
        'Équilibrage des roues disponible',
        'Ajustement de la pression des pneus',
        'Inspection visuelle des pneus'
      ],
      duration: language === 'en' ? '45-60 minutes' : '45-60 minutes'
    },
    {
      id: 'brake-service',
      title: t('brakeService'),
      frenchTitle: 'Entretien des freins',
      price: '$135 CAD',
      icon: Settings,
      image: '/images/brake-services.png',
      description: t('brakeServiceDesc'),
      features: language === 'en' ? [
        'Brake pad inspection & replacement',
        'Brake disc assessment',
        'Brake fluid check & top-up',
        'Brake system diagnostics',
        'Safety inspection'
      ] : [
        'Inspection et remplacement des plaquettes',
        'Évaluation des disques de frein',
        'Vérification et ajout de liquide de frein',
        'Diagnostic du système de freinage',
        'Inspection de sécurité'
      ],
      duration: language === 'en' ? '60-90 minutes' : '60-90 minutes'
    },
    {
      id: 'diagnostics',
      title: t('diagnostics'),
      frenchTitle: 'Diagnostic automobile',
      price: '$90 CAD',
      icon: Gauge,
      image: '/images/diagnostics.png',
      description: t('diagnosticsDesc'),
      features: language === 'en' ? [
        'OBD-II diagnostic scanning',
        'Engine performance analysis',
        'Error code reading & interpretation',
        'System health assessment',
        'Repair recommendations'
      ] : [
        'Lecture diagnostic OBD-II',
        'Analyse de performance du moteur',
        'Lecture et interprétation des codes d\'erreur',
        'Évaluation de l\'état des systèmes',
        'Recommandations de réparation'
      ],
      duration: language === 'en' ? '45-60 minutes' : '45-60 minutes'
    },
    {
      id: 'car-electrical-service',
      title: t('carElectricalService'),
      frenchTitle: 'Service électrique automobile',
      price: '$120 CAD',
      icon: Settings,
      image: '/images/car-electrical-service.webp',
      description: t('carElectricalServiceDesc'),
      features: language === 'en' ? [
        'Electrical system diagnosis',
        'Wiring repair and replacement',
        'Alternator and starter service',
        'Lighting system repair',
        'Computer system diagnostics'
      ] : [
        'Diagnostic du système électrique',
        'Réparation et remplacement de câblage',
        'Service d\'alternateur et démarreur',
        'Réparation du système d\'éclairage',
        'Diagnostic des systèmes informatiques'
      ],
      duration: language === 'en' ? '60-90 minutes' : '60-90 minutes'
    },
    {
      id: 'battery-service',
      title: t('batteryService'),
      frenchTitle: 'Service de batterie',
      price: '$80 CAD',
      icon: Car,
      image: '/images/battery-service.png',
      description: t('batteryServiceDesc'),
      features: language === 'en' ? [
        'Battery testing and analysis',
        'Battery replacement',
        'Charging system inspection',
        'Terminal cleaning and protection',
        'Load testing'
      ] : [
        'Test et analyse de batterie',
        'Remplacement de batterie',
        'Inspection du système de charge',
        'Nettoyage et protection des bornes',
        'Test de charge'
      ],
      duration: language === 'en' ? '30-45 minutes' : '30-45 minutes'
    },
    {
      id: 'exhaust-muffler-service',
      title: t('exhaustMufflerService'),
      frenchTitle: 'Service d\'échappement et silencieux',
      price: '$150 CAD',
      icon: Wrench,
      image: '/images/exhaust-muffler-service.jpeg',
      description: t('exhaustMufflerServiceDesc'),
      features: language === 'en' ? [
        'Exhaust system inspection',
        'Muffler replacement',
        'Catalytic converter service',
        'Pipe repair and replacement',
        'Emissions testing'
      ] : [
        'Inspection du système d\'échappement',
        'Remplacement de silencieux',
        'Service du convertisseur catalytique',
        'Réparation et remplacement de tuyaux',
        'Test d\'émissions'
      ],
      duration: language === 'en' ? '90-120 minutes' : '90-120 minutes'
    },
    {
      id: 'suspension-steering',
      title: t('suspensionSteering'),
      frenchTitle: 'Suspension et direction',
      price: '$200 CAD',
      icon: Settings,
      image: '/images/suspension-steering.png',
      description: t('suspensionSteeringDesc'),
      features: language === 'en' ? [
        'Suspension component inspection',
        'Strut and shock replacement',
        'Steering alignment',
        'Ball joint service',
        'Tire wear analysis'
      ] : [
        'Inspection des composants de suspension',
        'Remplacement d\'amortisseurs',
        'Alignement de direction',
        'Service des rotules',
        'Analyse d\'usure des pneus'
      ],
      duration: language === 'en' ? '120-180 minutes' : '120-180 minutes'
    }
  ];

  return (
    <div className="relative min-h-screen">
      {/* Background Image avec overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/services-background.png"
          alt="Services Background"
          fill
          className="object-cover"
          quality={100}
          priority
        />
        <div className="absolute inset-0 bg-black/70"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="pt-20 pb-16 text-center">
            <div className="animate-fade-in">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                {t('services')}
              </h1>
              <div className="h-1 w-24 bg-gradient-to-r from-[#E50914] to-[#B91C1C] mx-auto mb-8 rounded-full animate-pulse-glow"></div>
              <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto mb-12 leading-relaxed font-light">
                {language === 'en' 
                  ? 'Professional automotive services delivered to your location with transparent pricing and quality guarantee.'
                  : 'Services automobiles professionnels livrés à votre emplacement avec des prix transparents et une garantie de qualité.'
                }
              </p>
              
              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                <Link 
                  href="/contact" 
                  className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-white rounded-xl bg-gradient-to-r from-[#E50914] to-[#B91C1C] shadow-2xl shadow-red-500/25 hover:shadow-red-500/40 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
                >
                  <span className="absolute inset-0 rounded-xl bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                  <span className="relative flex items-center gap-3">
                    {t('bookNow')}
                    <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </span>
                </Link>
                
                <a 
                  href="tel:450-613-3778" 
                  className="group inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-white rounded-xl border-2 border-white/20 hover:border-[#E50914] hover:bg-[#E50914]/10 transition-all duration-300 backdrop-blur-sm"
                >
                  <Phone className="h-5 w-5 mr-3 group-hover:animate-pulse" />
                  450-613-3778
                </a>
              </div>
            </div>
          </div>

          {/* Services Grid */}
          <div className="pb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <div 
                  key={service.id} 
                  className="group relative bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 hover:border-[#E50914]/50 transition-all duration-500 hover:shadow-2xl hover:shadow-[#E50914]/20 transform hover:scale-105 animate-slide-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {/* Price Badge */}
                  <div className="absolute -top-4 -right-4 z-20">
                    <div className="bg-gradient-to-r from-[#E50914] to-[#B91C1C] text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-bounce-subtle">
                      {service.price}
                    </div>
                  </div>

                  {/* Service Image */}
                  <div className="relative aspect-video rounded-t-2xl overflow-hidden bg-gray-800">
                    <Image
                      src={service.image}
                      alt={service.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-700"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-100 group-hover:opacity-80 transition-opacity duration-300"></div>
                    
                    {/* Duration Badge */}
                    <div className="absolute bottom-4 left-4">
                      <div className="flex items-center gap-2 bg-black/70 backdrop-blur-sm text-white px-3 py-1.5 rounded-full text-sm">
                        <Clock className="h-4 w-4 text-[#E50914]" />
                        <span className="font-medium">{service.duration}</span>
                      </div>
                    </div>

                    {/* Service Icon */}
                    <div className="absolute top-4 left-4">
                      <div className="p-3 bg-[#E50914]/20 backdrop-blur-sm rounded-xl border border-[#E50914]/30">
                        <service.icon className="h-6 w-6 text-[#E50914]" />
                      </div>
                    </div>
                  </div>

                  {/* Service Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#E50914] transition-colors duration-300">
                      {service.title}
                    </h3>
                    <p className="text-gray-300 text-sm mb-6 leading-relaxed">
                      {service.description}
                    </p>

                    {/* Features List */}
                    <div className="mb-6">
                      <h4 className="text-white font-semibold mb-3 text-sm flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-[#E50914]" />
                        {language === 'en' ? 'Services included:' : 'Services inclus :'}
                      </h4>
                      <ul className="space-y-2">
                        {service.features.slice(0, 4).map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-start gap-2 text-gray-300 text-sm">
                            <div className="h-1.5 w-1.5 rounded-full bg-[#E50914] mt-2 flex-shrink-0"></div>
                            <span className="leading-relaxed">{feature}</span>
                          </li>
                        ))}
                        {service.features.length > 4 && (
                          <li className="text-gray-400 text-xs pl-4 italic">
                            +{service.features.length - 4} {language === 'en' ? 'more services...' : 'autres services...'}
                          </li>
                        )}
                      </ul>
                    </div>
                    
                    {/* Book Now Button */}
                    <Link 
                      href="/contact" 
                      className="group/btn relative w-full inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white rounded-xl bg-gradient-to-r from-[#E50914] to-[#B91C1C] shadow-lg shadow-red-500/25 hover:shadow-red-500/40 transition-all duration-300 transform hover:scale-105"
                    >
                      <span className="absolute inset-0 rounded-xl bg-white/10 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"></span>
                      <span className="relative flex items-center gap-2">
                        <Wrench className="h-4 w-4" />
                        {t('bookNow')}
                        <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                      </span>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Additional Services Section */}
          <div className="pb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Emergency Services */}
              <div className="group bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 hover:border-[#E50914]/50 transition-all duration-500 p-8 animate-slide-up">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-4 bg-[#E50914]/20 rounded-2xl">
                    <Zap className="h-8 w-8 text-[#E50914]" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">
                      {language === 'en' ? 'Emergency Services' : 'Services d\'urgence'}
                    </h3>
                    <div className="h-0.5 w-16 bg-gradient-to-r from-[#E50914] to-transparent rounded-full"></div>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {language === 'en' 
                    ? 'Available 24/7 for emergency automotive repairs. Additional charges may apply for after-hours service.'
                    : 'Disponible 24h/24 et 7j/7 pour les réparations automobiles d\'urgence. Des frais supplémentaires peuvent s\'appliquer pour le service après les heures.'
                  }
                </p>
                
                <a 
                  href="tel:450-613-3778"
                  className="group/btn inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-[#E50914] rounded-xl border-2 border-[#E50914]/30 hover:border-[#E50914] hover:bg-[#E50914]/10 transition-all duration-300"
                >
                  <Phone className="h-4 w-4 mr-2 group-hover/btn:animate-pulse" />
                  {language === 'en' ? 'Call for Emergency' : 'Appeler pour urgence'}
                </a>
              </div>

              {/* Service Guarantee */}
              <div className="group bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 hover:border-[#E50914]/50 transition-all duration-500 p-8 animate-slide-up" style={{ animationDelay: '200ms' }}>
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-4 bg-[#E50914]/20 rounded-2xl">
                    <Shield className="h-8 w-8 text-[#E50914]" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">
                      {language === 'en' ? 'Service Guarantee' : 'Garantie de service'}
                    </h3>
                    <div className="h-0.5 w-16 bg-gradient-to-r from-[#E50914] to-transparent rounded-full"></div>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {language === 'en' 
                    ? 'All our work comes with a quality guarantee. Parts and labor warranty included for your peace of mind.'
                    : 'Tous nos travaux sont accompagnés d\'une garantie de qualité. Garantie des pièces et de la main-d\'œuvre incluse pour votre tranquillité d\'esprit.'
                  }
                </p>
                
                <div className="flex items-center gap-3 text-[#E50914] font-semibold">
                  <CheckCircle className="h-5 w-5" />
                  <span>
                    {language === 'en' ? 'Parts & Labor Guaranteed' : 'Pièces et main-d\'œuvre garanties'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slide-up {
          from { opacity: 0; transform: translateY(60px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px #E50914; }
          50% { box-shadow: 0 0 40px #E50914, 0 0 60px #E50914; }
        }
        
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-5px); }
        }
        
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
        
        .animate-slide-up {
          animation: slide-up 0.8s ease-out both;
        }
        
        .animate-pulse-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }
        
        .animate-bounce-subtle {
          animation: bounce-subtle 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
