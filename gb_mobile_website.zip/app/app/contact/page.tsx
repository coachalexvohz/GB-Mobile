
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock,
  Send,
  Calendar,
  User,
  MessageCircle,
  FileText,
  AlertTriangle,
  Settings,
  Gauge,
  Wrench,
  Zap,
  Car
} from 'lucide-react';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

export default function ContactPage() {
  const { language } = useLanguage();
  const [submissionsLoading, setSubmissionsLoading] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  
  const [submissionsForm, setSubmissionsForm] = useState({
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    mileage: '',
    engineType: '',
    transmission: '',
    observedSymptoms: '',
    problemSince: '',
    problemDescription: '',
    fullName: '',
    phoneNumber: '',
    emailAddress: ''
  });

  const [bookingForm, setBookingForm] = useState({
    name: '',
    email: '',
    phone: '',
    serviceRequested: 'oil-change',
    preferredDate: '',
    preferredTime: '',
    location: '',
    vehicleInfo: '',
    additionalNotes: ''
  });
  
  const t = (key: string) => getTranslation(language, key);

  const services = [
    { value: 'oil-change', label: t('oilChange') },
    { value: 'tire-change', label: t('tireChange') },
    { value: 'brake-service', label: t('brakeService') },
    { value: 'diagnostics', label: t('diagnostics') },
    { value: 'emergency', label: language === 'en' ? 'Emergency Repair' : 'Réparation d\'urgence' }
  ];

  const timeSlots = [
    '8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM',
    '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM',
    '4:00 PM', '5:00 PM', '6:00 PM'
  ];

  const handleSubmissionsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionsLoading(true);

    try {
      console.log('Sending submissions form data:', { 
        ...submissionsForm,
        language 
      });

      const response = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...submissionsForm,
          language 
        })
      });

      console.log('Response status:', response.status);
      const result = await response.json();
      console.log('Response data:', result);

      if (response.ok && result.success) {
        toast.success(result.message || (language === 'en' ? 'Quote request sent successfully!' : 'Demande de devis envoyée avec succès !'));
        setSubmissionsForm({ 
          vehicleMake: '',
          vehicleModel: '',
          vehicleYear: '',
          mileage: '',
          engineType: '',
          transmission: '',
          observedSymptoms: '',
          problemSince: '',
          problemDescription: '',
          fullName: '',
          phoneNumber: '',
          emailAddress: ''
        });
      } else {
        // Show specific error message from server
        const errorMessage = result.message || (language === 'en' ? 'Submission failed' : 'Échec de l\'envoi');
        console.error('Server error:', errorMessage);
        toast.error(errorMessage);
      }
    } catch (error) {
      console.error('Submissions form error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Network error';
      console.error('Network/Parse error:', errorMessage);
      
      // Show more specific error message
      if (errorMessage.includes('NetworkError') || errorMessage.includes('fetch')) {
        toast.error(language === 'en' ? 'Network error. Please check your connection and try again.' : 'Erreur réseau. Vérifiez votre connexion et réessayez.');
      } else {
        toast.error(language === 'en' ? 'Error sending request. Please try again or call us at 450-613-3778.' : 'Erreur lors de l\'envoi. Veuillez réessayer ou nous appeler au 450-613-3778.');
      }
    } finally {
      setSubmissionsLoading(false);
    }
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBookingLoading(true);

    try {
      const bookingData = { 
        name: bookingForm.name,
        email: bookingForm.email,
        phone: bookingForm.phone,
        service: bookingForm.serviceRequested,
        preferredDate: bookingForm.preferredDate,
        preferredTime: bookingForm.preferredTime,
        address: bookingForm.location,
        message: `Vehicle: ${bookingForm.vehicleInfo || 'Not specified'}\n\nAdditional Notes: ${bookingForm.additionalNotes || 'None'}`,
        language 
      };

      console.log('Sending booking data:', bookingData);

      const response = await fetch('/api/booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData)
      });

      console.log('Booking response status:', response.status);
      const result = await response.json();
      console.log('Booking response data:', result);

      if (response.ok && result.success) {
        toast.success(language === 'en' ? 'Booking request submitted! We\'ll contact you shortly.' : 'Demande de réservation soumise ! Nous vous contacterons bientôt.');
        setBookingForm({
          name: '', email: '', phone: '', serviceRequested: 'oil-change',
          preferredDate: '', preferredTime: '', location: '', vehicleInfo: '', additionalNotes: ''
        });
      } else {
        throw new Error(result.message || 'Booking failed');
      }
    } catch (error) {
      console.error('Booking form error:', error);
      toast.error(language === 'en' ? 'Error submitting booking. Please try again.' : 'Erreur lors de la réservation. Veuillez réessayer.');
    } finally {
      setBookingLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative font-['Inter',sans-serif]">
      {/* Premium Background with High-Tech Overlay */}
      <div className="fixed inset-0 z-0">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ 
            backgroundImage: 'url(/contact-bg-premium.png)',
            backgroundAttachment: 'fixed'
          }}
        />
        {/* Subtle metallic overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-gray-900/70 to-black/90" />
        {/* Premium red accent overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-red-950/30 via-transparent to-black/20" />
        {/* Chrome effect overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gray-400/5 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Premium Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 drop-shadow-2xl tracking-tight">
              <span className="bg-gradient-to-r from-white via-gray-100 to-red-100 bg-clip-text text-transparent">
                {t('contactTitle')}
              </span>
            </h1>
            <p className="text-xl text-gray-200 max-w-4xl mx-auto drop-shadow-lg leading-relaxed font-light">
              {language === 'en' 
                ? 'Submit your quote requests and schedule appointments through our premium digital interface for exceptional service!'
                : 'Soumettez vos demandes de devis et prenez rendez-vous via notre interface numérique premium pour un service exceptionnel !'
              }
            </p>
          </div>

          {/* Premium Alert Banner */}
          <div className="mb-8">
            <Alert className="bg-gradient-to-r from-red-900/40 via-red-800/30 to-red-900/40 backdrop-blur-md border border-red-500/50 shadow-2xl rounded-xl">
              <AlertTriangle className="h-5 w-5 text-red-300" />
              <AlertDescription className="text-white text-lg drop-shadow-lg font-medium">
                {t('siteNote')}
              </AlertDescription>
            </Alert>
          </div>

          {/* Premium Main Content */}
          <Tabs defaultValue="submissions" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-gray-900/90 via-gray-800/90 to-gray-900/90 backdrop-blur-md border border-gray-600/50 mb-12 shadow-2xl rounded-2xl p-2">
              <TabsTrigger 
                value="submissions" 
                className="text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white data-[state=active]:shadow-lg rounded-xl font-medium transition-all duration-300 hover:text-white"
              >
                <FileText className="h-4 w-4 mr-2" />
                {t('submissionsTitle')}
              </TabsTrigger>
              <TabsTrigger 
                value="appointments" 
                className="text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white data-[state=active]:shadow-lg rounded-xl font-medium transition-all duration-300 hover:text-white"
              >
                <Calendar className="h-4 w-4 mr-2" />
                {t('appointmentsTitle')}
              </TabsTrigger>
              <TabsTrigger 
                value="contact" 
                className="text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white data-[state=active]:shadow-lg rounded-xl font-medium transition-all duration-300 hover:text-white"
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                {t('contactInfo')}
              </TabsTrigger>
            </TabsList>

          {/* Premium Submissions Form */}
          <TabsContent value="submissions">
            <Card className="bg-gradient-to-br from-gray-900/95 via-gray-800/90 to-gray-900/95 backdrop-blur-xl border border-gray-600/50 shadow-2xl rounded-2xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 border-b border-gray-600/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-600/20 rounded-xl">
                    <FileText className="h-6 w-6 text-red-400" />
                  </div>
                  <CardTitle className="text-white text-2xl font-bold tracking-tight">{t('submissionsTitle')}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmissionsSubmit} className="space-y-10">
                  {/* Premium Vehicle Information Section */}
                  <div className="space-y-8">
                    <div className="flex items-center gap-3 mb-6">
                      <Car className="h-5 w-5 text-red-400" />
                      <h3 className="text-2xl font-bold text-white">
                        {t('vehicleInformation')}
                      </h3>
                      <div className="flex-1 h-px bg-gradient-to-r from-red-600/50 to-transparent"></div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Settings className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="vehicle-make" className="text-gray-200 font-medium">
                            {t('vehicleMake')} *
                          </Label>
                        </div>
                        <Input
                          id="vehicle-make"
                          value={submissionsForm.vehicleMake}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, vehicleMake: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                          placeholder={language === 'en' ? 'e.g., Honda' : 'ex: Honda'}
                        />
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Settings className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="vehicle-model" className="text-gray-200 font-medium">
                            {t('vehicleModel')} *
                          </Label>
                        </div>
                        <Input
                          id="vehicle-model"
                          value={submissionsForm.vehicleModel}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, vehicleModel: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                          placeholder={language === 'en' ? 'e.g., Civic' : 'ex: Civic'}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="vehicle-year" className="text-gray-200 font-medium">
                            {t('vehicleYear')} *
                          </Label>
                        </div>
                        <Input
                          id="vehicle-year"
                          value={submissionsForm.vehicleYear}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, vehicleYear: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                          placeholder={language === 'en' ? 'e.g., 2020' : 'ex: 2020'}
                        />
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Gauge className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="mileage" className="text-gray-200 font-medium">
                            {t('mileage')} *
                          </Label>
                        </div>
                        <Input
                          id="mileage"
                          value={submissionsForm.mileage}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, mileage: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                          placeholder={language === 'en' ? 'e.g., 75,000 km' : 'ex: 75 000 km'}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="engine-type" className="text-gray-200 font-medium">
                            {t('engineType')} *
                          </Label>
                        </div>
                        <Select
                          value={submissionsForm.engineType}
                          onValueChange={(value) => setSubmissionsForm({ ...submissionsForm, engineType: value })}
                          required
                        >
                          <SelectTrigger className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg">
                            <SelectValue placeholder={language === 'en' ? 'Select engine type' : 'Sélectionner le type de moteur'} />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border border-gray-600/50 rounded-xl shadow-2xl">
                            <SelectItem value="gasoline" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('gasoline')}
                            </SelectItem>
                            <SelectItem value="diesel" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('diesel')}
                            </SelectItem>
                            <SelectItem value="hybrid" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('hybrid')}
                            </SelectItem>
                            <SelectItem value="electric" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('electric')}
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Settings className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="transmission" className="text-gray-200 font-medium">
                            {t('transmission')} *
                          </Label>
                        </div>
                        <Select
                          value={submissionsForm.transmission}
                          onValueChange={(value) => setSubmissionsForm({ ...submissionsForm, transmission: value })}
                          required
                        >
                          <SelectTrigger className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg">
                            <SelectValue placeholder={language === 'en' ? 'Select transmission' : 'Sélectionner la transmission'} />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border border-gray-600/50 rounded-xl shadow-2xl">
                            <SelectItem value="manual" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('manual')}
                            </SelectItem>
                            <SelectItem value="automatic" className="text-white hover:bg-red-600/20 focus:bg-red-600/20 rounded-lg">
                              {t('automatic')}
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Wrench className="h-4 w-4 text-gray-400" />
                        <Label htmlFor="observed-symptoms" className="text-gray-200 font-medium">
                          {t('observedSymptoms')} *
                        </Label>
                      </div>
                      <Textarea
                        id="observed-symptoms"
                        value={submissionsForm.observedSymptoms}
                        onChange={(e) => setSubmissionsForm({ ...submissionsForm, observedSymptoms: e.target.value })}
                        required
                        rows={4}
                        className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg resize-none"
                        placeholder={language === 'en' 
                          ? 'Describe in detail the symptoms you have observed (noises, vibrations, warning lights, etc.)...'
                          : 'Décrivez en détail les symptômes que vous avez observés (bruits, vibrations, voyants d\'alerte, etc.)...'
                        }
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <Label htmlFor="problem-since" className="text-gray-200 font-medium">
                          {t('problemSince')} *
                        </Label>
                      </div>
                      <Input
                        id="problem-since"
                        value={submissionsForm.problemSince}
                        onChange={(e) => setSubmissionsForm({ ...submissionsForm, problemSince: e.target.value })}
                        required
                        className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                        placeholder={language === 'en' ? 'e.g., Since last week, 2 months ago' : 'ex: Depuis la semaine dernière, il y a 2 mois'}
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-gray-400" />
                        <Label htmlFor="problem-description" className="text-gray-200 font-medium">
                          {t('problemDescription')}
                        </Label>
                      </div>
                      <Textarea
                        id="problem-description"
                        value={submissionsForm.problemDescription}
                        onChange={(e) => setSubmissionsForm({ ...submissionsForm, problemDescription: e.target.value })}
                        rows={3}
                        className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg resize-none"
                        placeholder={language === 'en' 
                          ? 'Any additional information about the problem...'
                          : 'Toute information supplémentaire concernant le problème...'
                        }
                      />
                    </div>
                  </div>

                  {/* Premium Contact Information Section */}
                  <div className="space-y-8">
                    <div className="flex items-center gap-3 mb-6">
                      <User className="h-5 w-5 text-red-400" />
                      <h3 className="text-2xl font-bold text-white">
                        {t('contactInfo')}
                      </h3>
                      <div className="flex-1 h-px bg-gradient-to-r from-red-600/50 to-transparent"></div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="full-name" className="text-gray-200 font-medium">
                            {t('fullName')} *
                          </Label>
                        </div>
                        <Input
                          id="full-name"
                          value={submissionsForm.fullName}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, fullName: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                        />
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-gray-400" />
                          <Label htmlFor="phone-number" className="text-gray-200 font-medium">
                            {t('phoneNumber')} *
                          </Label>
                        </div>
                        <Input
                          id="phone-number"
                          type="tel"
                          value={submissionsForm.phoneNumber}
                          onChange={(e) => setSubmissionsForm({ ...submissionsForm, phoneNumber: e.target.value })}
                          required
                          className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <Label htmlFor="email-address" className="text-gray-200 font-medium">
                          {t('emailAddress')} *
                        </Label>
                      </div>
                      <Input
                        id="email-address"
                        type="email"
                        value={submissionsForm.emailAddress}
                        onChange={(e) => setSubmissionsForm({ ...submissionsForm, emailAddress: e.target.value })}
                        required
                        className="bg-gray-800/70 border border-gray-600/50 text-white rounded-xl px-4 py-3 text-lg font-medium placeholder:text-gray-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all duration-300 hover:border-gray-500 shadow-lg"
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={submissionsLoading}
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 px-8 rounded-xl text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-red-500/25 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    <div className="flex items-center justify-center gap-3">
                      {submissionsLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          {t('loading')}
                        </>
                      ) : (
                        <>
                          <Send className="h-5 w-5" />
                          {t('sendButton')}
                        </>
                      )}
                    </div>
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Premium Appointments Form */}
          <TabsContent value="appointments">
            <Card className="bg-gradient-to-br from-gray-900/95 via-gray-800/90 to-gray-900/95 backdrop-blur-xl border border-gray-600/50 shadow-2xl rounded-2xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 border-b border-gray-600/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-600/20 rounded-xl">
                    <Calendar className="h-6 w-6 text-red-400" />
                  </div>
                  <CardTitle className="text-white text-2xl font-bold tracking-tight">{t('appointmentsTitle')}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
                  <iframe
                    src="https://calendly.com/coachalexvohz/30min"
                    width="100%"
                    height="700"
                    frameBorder="0"
                    title="Schedule Appointment"
                    className="rounded-2xl"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Premium Contact Information */}
          <TabsContent value="contact">
            <Card className="bg-gradient-to-br from-gray-900/95 via-gray-800/90 to-gray-900/95 backdrop-blur-xl border border-gray-600/50 shadow-2xl rounded-2xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 border-b border-gray-600/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-600/20 rounded-xl">
                    <MessageCircle className="h-6 w-6 text-red-400" />
                  </div>
                  <CardTitle className="text-white text-2xl font-bold tracking-tight">{t('contactInfo')}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-8 space-y-8">
                {/* Premium Phone Numbers */}
                <div className="space-y-6">
                  <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-600/30 hover:border-red-500/50 transition-all duration-300">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-red-600/20 rounded-lg">
                        <Phone className="h-5 w-5 text-red-400" />
                      </div>
                      <span className="text-white font-bold text-lg">{t('primaryPhone')}</span>
                    </div>
                    <a 
                      href="tel:450-613-3778"
                      className="text-gray-200 hover:text-red-400 transition-colors pl-12 text-xl font-medium"
                    >
                      450-613-3778
                    </a>
                  </div>

                  <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-600/30 hover:border-red-500/50 transition-all duration-300">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-red-600/20 rounded-lg">
                        <Phone className="h-5 w-5 text-red-400" />
                      </div>
                      <span className="text-white font-bold text-lg">{t('secondaryPhone')}</span>
                    </div>
                    <a 
                      href="tel:450-612-3778"
                      className="text-gray-200 hover:text-red-400 transition-colors pl-12 text-xl font-medium"
                    >
                      450-612-3778
                    </a>
                  </div>

                  {/* Premium Email */}
                  <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-600/30 hover:border-red-500/50 transition-all duration-300">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-red-600/20 rounded-lg">
                        <Mail className="h-5 w-5 text-red-400" />
                      </div>
                      <span className="text-white font-bold text-lg">{t('email')}</span>
                    </div>
                    <a 
                      href="mailto:gb_mobile99@outlook.com"
                      className="text-gray-200 hover:text-red-400 transition-colors pl-12 text-xl font-medium break-all"
                    >
                      gb_mobile99@outlook.com
                    </a>
                  </div>

                  {/* Premium Service Area */}
                  <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-600/30">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-red-600/20 rounded-lg">
                        <MapPin className="h-5 w-5 text-red-400" />
                      </div>
                      <span className="text-white font-bold text-lg">{t('serviceAreaTitle')}</span>
                    </div>
                    <p className="text-gray-200 pl-12 text-xl font-medium">
                      Lachute, Mirabel, Saint-Jérôme {language === 'en' ? '& surrounding areas' : 'et environs'}
                    </p>
                  </div>

                  {/* Premium Hours */}
                  <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-600/30">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-red-600/20 rounded-lg">
                        <Clock className="h-5 w-5 text-red-400" />
                      </div>
                      <span className="text-white font-bold text-lg">
                        {language === 'en' ? 'Service Hours' : 'Heures de service'}
                      </span>
                    </div>
                    <p className="text-gray-200 pl-12 text-xl font-medium">
                      {language === 'en' ? '24/7 Emergency Service Available' : 'Service d\'urgence 24h/24 disponible'}
                    </p>
                  </div>
                </div>

                {/* Premium Call Now Button */}
                <div className="pt-6">
                  <Button 
                    asChild
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 px-8 rounded-xl text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-red-500/25"
                  >
                    <a href="tel:450-613-3778" className="flex items-center justify-center gap-3">
                      <Phone className="h-5 w-5" />
                      {t('callNow')}
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

          {/* Premium Emergency Contact */}
          <Card className="bg-gradient-to-br from-red-900/50 via-red-800/40 to-red-900/50 backdrop-blur-xl border border-red-500/50 shadow-2xl rounded-2xl mt-12 overflow-hidden">
            <CardContent className="p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-red-600/30 rounded-2xl">
                  <AlertTriangle className="h-12 w-12 text-red-300" />
                </div>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4 tracking-tight">
                {language === 'en' ? 'Emergency Service Available 24/7' : 'Service d\'urgence disponible 24h/24'}
              </h2>
              <p className="text-gray-200 mb-8 text-lg font-light max-w-2xl mx-auto leading-relaxed">
                {language === 'en' 
                  ? 'Need immediate assistance? Call us now for emergency automotive repair service.'
                  : 'Besoin d\'aide immédiate ? Appelez-nous maintenant pour un service de réparation automobile d\'urgence.'
                }
              </p>
              <Button 
                asChild
                size="lg"
                className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 px-12 rounded-xl text-xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-red-500/25"
              >
                <a href="tel:450-613-3778" className="flex items-center gap-3">
                  <Phone className="h-6 w-6" />
                  450-613-3778
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
