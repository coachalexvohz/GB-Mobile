
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { Toaster } from 'sonner';
import { LanguageProvider } from '@/contexts/LanguageContext';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'GB Mobile - Professional Mobile Automotive Repair | Lachute & Surrounding Areas',
  description: 'Expert mobile mechanic service in Lachute, Quebec. 24/7 emergency repairs, oil changes, brake service, diagnostics. Certified automotive mechanic with 10+ years experience.',
  keywords: 'mobile mechanic, automotive repair, Lachute, Quebec, oil change, brake service, diagnostics, emergency repair',
  authors: [{ name: 'GB Mobile' }],
  openGraph: {
    title: 'GB Mobile - Professional Mobile Automotive Repair',
    description: 'Expert mobile mechanic service in Lachute, Quebec. 24/7 emergency repairs, transparent pricing, guaranteed work.',
    type: 'website',
    locale: 'en_CA',
    alternateLocale: 'fr_CA',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.className} bg-gray-900 text-white min-h-screen`}>
        <LanguageProvider>
          <Header />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
          <Toaster position="top-center" richColors />
        </LanguageProvider>
      </body>
    </html>
  );
}
