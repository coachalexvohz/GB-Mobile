
import { NextRequest, NextResponse } from 'next/server'
import { sendBookingEmail } from '@/lib/resend'
import { z } from 'zod'

const bookingSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().min(10, 'Valid phone number is required'),
  service: z.string().min(1, 'Service selection is required'),
  preferredDate: z.string().min(1, 'Preferred date is required'),
  preferredTime: z.string().min(1, 'Preferred time is required'),
  address: z.string().min(10, 'Complete address is required'),
  message: z.string().optional(),
  language: z.enum(['fr', 'en']).default('fr')
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate the data
    const validatedData = bookingSchema.parse(body)
    
    // Send the booking email
    const result = await sendBookingEmail(validatedData)
    
    if (result.success) {
      return NextResponse.json(
        { 
          message: validatedData.language === 'fr' 
            ? 'Demande de réservation envoyée avec succès! Nous vous contacterons dans les plus brefs délais.' 
            : 'Booking request sent successfully! We will contact you as soon as possible.',
          success: true 
        },
        { status: 200 }
      )
    } else {
      throw new Error('Failed to send booking email')
    }
  } catch (error) {
    console.error('Booking form error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          message: 'Validation error',
          errors: error.errors,
          success: false 
        },
        { status: 400 }
      )
    }
    
    return NextResponse.json(
      { 
        message: 'Failed to send booking request. Please try again.',
        success: false 
      },
      { status: 500 }
    )
  }
}
