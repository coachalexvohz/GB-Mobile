
import { NextRequest, NextResponse } from 'next/server'
import { sendContactEmail } from '@/lib/resend'
import { z } from 'zod'

const contactSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().optional(),
  message: z.string().min(3, 'Message must be at least 3 characters'),
  language: z.enum(['fr', 'en']).default('fr')
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate the data
    const validatedData = contactSchema.parse(body)
    
    // Send the email
    const result = await sendContactEmail(validatedData)
    
    if (result.success) {
      return NextResponse.json(
        { 
          message: validatedData.language === 'fr' 
            ? 'Message envoyé avec succès!' 
            : 'Message sent successfully!',
          success: true 
        },
        { status: 200 }
      )
    } else {
      throw new Error('Failed to send email')
    }
  } catch (error) {
    console.error('Contact form error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          message: 'Validation error',
          errors: error.errors,
          success: false 
        },
        { status: 400 }
      )
    }
    
    return NextResponse.json(
      { 
        message: 'Failed to send message. Please try again.',
        success: false 
      },
      { status: 500 }
    )
  }
}
