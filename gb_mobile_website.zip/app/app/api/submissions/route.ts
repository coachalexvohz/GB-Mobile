

import { NextResponse } from 'next/server';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    console.log('Submission API called');

    const { 
      vehicleMake, 
      vehicleModel, 
      vehicleYear,
      mileage,
      engineType,
      transmission,
      observedSymptoms,
      problemSince,
      problemDescription, 
      fullName, 
      phoneNumber, 
      emailAddress,
      language = 'fr' 
    } = await req.json();

    console.log('Received submission data:', {
      vehicleMake,
      vehicleModel,
      vehicleYear,
      fullName,
      phoneNumber,
      emailAddress,
      language
    });

    const isEnglish = language === 'en';
    
    // Send email notification
    const { data, error } = await resend.emails.send({
      from: 'GB Mobile <noreply@gbmobile.ca>',
      to: ['gb_mobile99@outlook.com', 'coachalexvohz@gmail.com'],
      subject: isEnglish ? `New Quote Request from ${fullName}` : `Nouvelle demande de devis de ${fullName}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto;">
          <div style="background-color: #dc2626; color: white; padding: 20px; text-align: center;">
            <h1 style="margin: 0; font-size: 24px;">
              ${isEnglish ? 'New Quote Request' : 'Nouvelle demande de devis'}
            </h1>
          </div>
          
          <div style="padding: 20px; background-color: #f9f9f9;">
            <h2 style="color: #374151; margin-bottom: 20px;">
              ${isEnglish ? 'Client Information' : 'Informations du client'}
            </h2>
            
            <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
              <p><strong>${isEnglish ? 'Name:' : 'Nom :'}</strong> ${fullName}</p>
              <p><strong>${isEnglish ? 'Phone:' : 'Téléphone :'}</strong> ${phoneNumber}</p>
              <p><strong>${isEnglish ? 'Email:' : 'Courriel :'}</strong> ${emailAddress}</p>
            </div>

            <h2 style="color: #374151; margin-bottom: 20px;">
              ${isEnglish ? 'Vehicle Information' : 'Informations du véhicule'}
            </h2>
            
            <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
              <p><strong>${isEnglish ? 'Vehicle Make:' : 'Marque du véhicule :'}</strong> ${vehicleMake}</p>
              <p><strong>${isEnglish ? 'Vehicle Model:' : 'Modèle du véhicule :'}</strong> ${vehicleModel}</p>
              <p><strong>${isEnglish ? 'Vehicle Year:' : 'Année du véhicule :'}</strong> ${vehicleYear}</p>
              <p><strong>${isEnglish ? 'Mileage:' : 'Kilométrage :'}</strong> ${mileage}</p>
              <p><strong>${isEnglish ? 'Engine Type:' : 'Type de moteur :'}</strong> ${isEnglish ? 
                (engineType === 'gasoline' ? 'Gasoline' : 
                 engineType === 'diesel' ? 'Diesel' :
                 engineType === 'hybrid' ? 'Hybrid' :
                 engineType === 'electric' ? 'Electric' : engineType) :
                (engineType === 'gasoline' ? 'Essence' : 
                 engineType === 'diesel' ? 'Diesel' :
                 engineType === 'hybrid' ? 'Hybride' :
                 engineType === 'electric' ? 'Électrique' : engineType)
              }</p>
              <p><strong>${isEnglish ? 'Transmission:' : 'Transmission :'}</strong> ${isEnglish ? 
                (transmission === 'manual' ? 'Manual' : 
                 transmission === 'automatic' ? 'Automatic' : transmission) :
                (transmission === 'manual' ? 'Manuelle' : 
                 transmission === 'automatic' ? 'Automatique' : transmission)
              }</p>
            </div>

            <h2 style="color: #374151; margin-bottom: 20px;">
              ${isEnglish ? 'Problem Details' : 'Détails du problème'}
            </h2>
            
            <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
              <p><strong>${isEnglish ? 'Observed Symptoms:' : 'Symptômes observés :'}</strong></p>
              <p style="white-space: pre-line; background-color: #f8f9fa; padding: 15px; border-left: 4px solid #dc2626; margin: 10px 0;">${observedSymptoms}</p>
              
              <p><strong>${isEnglish ? 'Problem Duration:' : 'Depuis quand le problème est présent :'}</strong> ${problemSince}</p>
              
              ${problemDescription ? `
                <p><strong>${isEnglish ? 'Additional Information:' : 'Informations supplémentaires :'}</strong></p>
                <p style="white-space: pre-line; background-color: #f8f9fa; padding: 15px; border-left: 4px solid #dc2626; margin: 10px 0;">${problemDescription}</p>
              ` : ''}
            </div>
          </div>
          
          <div style="background-color: #374151; color: white; padding: 20px; text-align: center;">
            <p style="margin: 0;">
              ${isEnglish ? 
                'Contact the client as soon as possible to provide a quote.' : 
                'Contactez le client dès que possible pour fournir un devis.'
              }
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.error('Resend error:', error);
      return NextResponse.json({ 
        success: false, 
        message: isEnglish ? 'Failed to send email. Please try again.' : 'Échec de l\'envoi de l\'e-mail. Veuillez réessayer.'
      }, { status: 500 });
    }

    console.log('Submission email sent successfully:', data);
    
    return NextResponse.json({ 
      success: true, 
      message: isEnglish ? 'Quote request sent successfully!' : 'Demande de devis envoyée avec succès !'
    });

  } catch (error) {
    console.error('Submission API error:', error);
    return NextResponse.json({ 
      success: false, 
      message: 'Internal server error'
    }, { status: 500 });
  }
}
