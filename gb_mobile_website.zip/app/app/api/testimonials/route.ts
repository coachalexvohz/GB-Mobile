
import { NextRequest, NextResponse } from 'next/server'
import { sendTestimonialNotification } from '@/lib/resend'
import { z } from 'zod'

const testimonialSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email().optional().or(z.literal('')),
  rating: z.number().min(1).max(5, 'Rating must be between 1 and 5'),
  comment: z.string().min(3, 'Comment must be at least 3 characters'),
  service: z.string().optional(),
  language: z.enum(['fr', 'en']).default('fr')
})

// Handle GET requests (for loading testimonials)
export async function GET() {
  try {
    // Return empty testimonials array for now
    // In a real application, this would fetch from a database
    return NextResponse.json(
      { 
        testimonials: [],
        success: true 
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Error loading testimonials:', error)
    return NextResponse.json(
      { 
        message: 'Failed to load testimonials',
        testimonials: [],
        success: false 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate the data
    const validatedData = testimonialSchema.parse(body)
    
    // Clean up empty email
    if (validatedData.email === '') {
      validatedData.email = undefined
    }
    
    // Send notification email
    const result = await sendTestimonialNotification(validatedData)
    
    if (result.success) {
      return NextResponse.json(
        { 
          message: validatedData.language === 'fr' 
            ? 'Merci pour votre témoignage! Il sera examiné et ajouté au site.' 
            : 'Thank you for your testimonial! It will be reviewed and added to the site.',
          success: true 
        },
        { status: 200 }
      )
    } else {
      throw new Error('Failed to send testimonial notification')
    }
  } catch (error) {
    console.error('Testimonial form error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          message: 'Validation error',
          errors: error.errors,
          success: false 
        },
        { status: 400 }
      )
    }
    
    return NextResponse.json(
      { 
        message: 'Failed to send testimonial. Please try again.',
        success: false 
      },
      { status: 500 }
    )
  }
}
