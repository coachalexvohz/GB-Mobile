
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Clock, 
  Phone,
  Navigation,
  CheckCircle
} from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ServiceAreaPage() {
  const { language } = useLanguage();
  
  const t = (key: string) => getTranslation(language, key);

  const primaryArea = {
    name: 'Lachute',
    description: language === 'en' 
      ? 'Our primary service area with fastest response times'
      : 'Notre zone de service principale avec les temps de réponse les plus rapides'
  };

  const serviceAreas = [
    'Mirabel',
    'Saint-Jérôme', 
    'Brownsburg-Chatham',
    'Grenville',
    'Saint-André-d\'Argenteuil',
    'Wentworth',
    'Morin-Heights'
  ];

  const serviceFeatures = [
    {
      icon: Clock,
      title: language === 'en' ? '24/7 Emergency Service' : 'Service d\'urgence 24h/24',
      description: language === 'en' 
        ? 'Available around the clock for emergency repairs'
        : 'Disponible 24h/24 pour les réparations d\'urgence'
    },
    {
      icon: Navigation,
      title: language === 'en' ? 'Mobile Service' : 'Service mobile',
      description: language === 'en'
        ? 'We come to your location - home, work, or roadside'
        : 'Nous venons à votre emplacement - domicile, travail ou bord de route'
    },
    {
      icon: CheckCircle,
      title: language === 'en' ? 'No Extra Travel Fees' : 'Aucun frais de déplacement supplémentaire',
      description: language === 'en'
        ? 'Travel costs included in service pricing'
        : 'Frais de déplacement inclus dans le prix du service'
    }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <Image
          src="/images/service-area-bg.png"
          alt="Service Area Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Hero Section */}
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-['Inter'] tracking-tight">
              {t('serviceAreaTitle')}
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed font-['Inter']">
              {language === 'en' 
                ? 'Professional mobile automotive repair service covering Lachute and surrounding communities'
                : 'Service de réparation automobile mobile professionnel couvrant Lachute et les communautés environnantes'
              }
            </p>
          </div>

          {/* Primary Service Area */}
          <section className="mb-16 animate-slide-up">
            <div className="bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl shadow-2xl p-8 hover:shadow-red-500/10 transition-all duration-300">
              <div className="text-center">
                <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full w-fit shadow-lg">
                  <MapPin className="h-12 w-12 text-white" />
                </div>
                <h2 className="text-white text-3xl font-bold mb-3 font-['Inter'] tracking-tight">
                  {t('primaryArea')}
                </h2>
                <Badge variant="outline" className="border-[#E50914] bg-[#E50914]/10 text-[#E50914] text-lg px-6 py-2 rounded-full font-medium">
                  {primaryArea.name}
                </Badge>
              </div>
              <div className="text-center mt-6">
                <p className="text-gray-200 text-lg mb-8 font-['Inter']">
                  {primaryArea.description}
                </p>
                <div className="flex flex-col sm:flex-row gap-6 justify-center">
                  <Button 
                    asChild
                    size="lg"
                    className="bg-gradient-to-r from-[#E50914] to-[#B8070F] hover:from-[#B8070F] hover:to-[#E50914] text-white font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/25"
                  >
                    <Link href="/contact" className="font-['Inter']">
                      {t('bookNow')}
                    </Link>
                  </Button>
                  <Button 
                    asChild
                    size="lg"
                    variant="outline"
                    className="border-2 border-[#E50914] bg-transparent text-[#E50914] hover:bg-[#E50914] hover:text-white font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105"
                  >
                    <a href="tel:450-613-3778" className="flex items-center gap-2 font-['Inter']">
                      <Phone className="h-5 w-5" />
                      450-613-3778
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Coverage Areas */}
          <section className="mb-16 animate-slide-up">
            <h2 className="text-3xl font-bold text-white text-center mb-12 font-['Inter'] tracking-tight">
              {t('coverageAreas')}
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              {serviceAreas.map((area, index) => (
                <div 
                  key={area} 
                  className={`bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-xl p-6 text-center hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/10 animate-fade-in`}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <MapPin className="h-8 w-8 text-[#E50914] mx-auto mb-3" />
                  <p className="text-white font-medium font-['Inter']">{area}</p>
                </div>
              ))}
            </div>
            <div className="text-center bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-xl p-6">
              <p className="text-gray-200 mb-4 font-['Inter']">
                {language === 'en' 
                  ? 'Don\'t see your area? Contact us - we may be able to help!'
                  : 'Vous ne voyez pas votre région ? Contactez-nous - nous pourrons peut-être vous aider !'
                }
              </p>
              <Button 
                asChild 
                variant="outline" 
                className="border-2 border-gray-400 bg-transparent text-gray-300 hover:bg-gray-700 hover:text-white font-medium px-6 py-2 rounded-full transition-all duration-300"
              >
                <Link href="/contact" className="font-['Inter']">
                  {language === 'en' ? 'Contact Us' : 'Nous contacter'}
                </Link>
              </Button>
            </div>
          </section>

          {/* Service Features */}
          <section className="mb-16 animate-slide-up">
            <h2 className="text-3xl font-bold text-white text-center mb-12 font-['Inter'] tracking-tight">
              {language === 'en' ? 'Service Features' : 'Caractéristiques du service'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {serviceFeatures.map((feature, index) => (
                <div 
                  key={index} 
                  className={`bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl p-8 text-center hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/10 animate-fade-in`}
                  style={{ animationDelay: `${index * 150}ms` }}
                >
                  <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full w-fit shadow-lg">
                    <feature.icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-white text-xl font-bold mb-4 font-['Inter'] tracking-tight">
                    {feature.title}
                  </h3>
                  <p className="text-gray-200 font-['Inter'] leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Emergency Notice */}
          <section className="animate-slide-up">
            <div className="bg-[#E50914]/10 backdrop-blur-lg border-2 border-[#E50914]/30 rounded-2xl p-8 shadow-2xl hover:shadow-red-500/20 transition-all duration-300">
              <div className="text-center">
                <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full w-fit shadow-lg animate-pulse">
                  <Clock className="h-10 w-10 text-white" />
                </div>
                <h2 className="text-white text-3xl font-bold mb-4 font-['Inter'] tracking-tight">
                  {t('emergencyAvailable')}
                </h2>
              </div>
              <div className="text-center">
                <p className="text-gray-200 mb-8 text-lg font-['Inter'] leading-relaxed">
                  {language === 'en' 
                    ? 'Stranded on the road? We provide 24/7 emergency automotive repair services throughout our coverage area.'
                    : 'Coincé sur la route ? Nous offrons des services de réparation automobile d\'urgence 24h/24 et 7j/7 dans toute notre zone de couverture.'
                  }
                </p>
                <Button 
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-[#E50914] to-[#B8070F] hover:from-[#B8070F] hover:to-[#E50914] text-white text-lg px-10 py-4 rounded-full font-bold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/25"
                >
                  <a href="tel:450-613-3778" className="flex items-center gap-3 font-['Inter']">
                    <Phone className="h-6 w-6" />
                    {language === 'en' ? 'Call Now for Emergency' : 'Appeler maintenant pour urgence'}
                  </a>
                </Button>
                <p className="text-gray-400 text-sm mt-6 font-['Inter']">
                  {language === 'en' 
                    ? 'Additional charges may apply for after-hours emergency service'
                    : 'Des frais supplémentaires peuvent s\'appliquer pour le service d\'urgence après les heures'
                  }
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slide-up {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
        
        .animate-slide-up {
          animation: slide-up 1s ease-out;
        }
      `}</style>
    </div>
  );
}
