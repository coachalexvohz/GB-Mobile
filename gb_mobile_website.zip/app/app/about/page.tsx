
'use client';

import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Award, 
  Clock, 
  MapPin, 
  Wrench, 
  Shield,
  CheckCircle,
  Users,
  Calendar,
  DollarSign,
  Phone,
  Car,
  Star,
  ThumbsUp,
  Target,
  Heart
} from 'lucide-react';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function AboutPage() {
  const { language } = useLanguage();
  const t = (key: string) => getTranslation(language, key);

  const qualityAssurances = [
    {
      icon: Shield,
      iconColor: 'text-blue-500',
      title: language === 'en' ? 'Repair Warranty' : 'Garantie sur les réparations',
      description: language === 'en'
        ? 'All our work is guaranteed. Your satisfaction is our absolute priority.'
        : 'Tous nos travaux sont garantis. Votre satisfaction est notre priorité absolue.'
    },
    {
      icon: Clock,
      iconColor: 'text-orange-500',
      title: language === 'en' ? 'Deadline Respect' : 'Respect des délais',
      description: language === 'en'
        ? 'We arrive at the agreed time and respect the announced intervention times.'
        : 'Nous arrivons à l\'heure convenue et respectons les temps d\'intervention annoncés.'
    },
    {
      icon: ThumbsUp,
      iconColor: 'text-green-500',
      title: language === 'en' ? 'Quality Parts' : 'Pièces de qualité',
      description: language === 'en'
        ? 'We only use OEM or equivalent quality parts for your repairs.'
        : 'Nous utilisons uniquement des pièces OEM ou de qualité équivalente pour vos réparations.'
    },
    {
      icon: Star,
      iconColor: 'text-purple-500',
      title: language === 'en' ? 'After-Sales Service' : 'Service après-vente',
      description: language === 'en'
        ? 'Our relationship doesn\'t end after the intervention. We remain available for your questions.'
        : 'Notre relation ne s\'arrête pas après l\'intervention. Nous restons disponibles pour vos questions.'
    }
  ];

  const fundamentalValues = [
    {
      icon: Wrench,
      iconColor: 'text-blue-500',
      title: language === 'en' ? 'Technical Excellence' : 'Excellence technique',
      description: language === 'en'
        ? 'We use professional tools and quality parts to guarantee durable and reliable work.'
        : 'Nous utilisons des outils professionnels et des pièces de qualité pour garantir un travail durable et fiable.'
    },
    {
      icon: Heart,
      iconColor: 'text-orange-500',
      title: language === 'en' ? 'Personalized Service' : 'Service personnalisé',
      description: language === 'en'
        ? 'Each client is unique. We take the time to listen to your needs and adapt our service accordingly.'
        : 'Chaque client est unique. Nous prenons le temps d\'écouter vos besoins et d\'adapter notre service en conséquence.'
    },
    {
      icon: Target,
      iconColor: 'text-green-500',
      title: language === 'en' ? 'Total Transparency' : 'Transparence totale',
      description: language === 'en'
        ? 'Clear quotes, detailed explanations, fixed prices. No surprises, just transparency.'
        : 'Devis clairs, explications détaillées, prix fixes. Pas de surprise, que de la transparence.'
    }
  ];

  const stats = [
    { value: '5+', label: language === 'en' ? 'Years of experience' : 'Années d\'expérience', icon: Shield, iconColor: 'text-blue-500' },
    { value: '500+', label: language === 'en' ? 'Satisfied clients' : 'Clients satisfaits', icon: Users, iconColor: 'text-orange-500' },
    { value: '100%', label: language === 'en' ? 'Recommended' : 'Recommandé', icon: CheckCircle, iconColor: 'text-green-500' }
  ];

  const reputationStats = [
    { value: '4.6★', label: language === 'en' ? 'Google Rating' : 'Note Google' },
    { value: '100%', label: language === 'en' ? 'Recommended Facebook' : 'Recommandé Facebook' },
    { value: '500+', label: language === 'en' ? 'Satisfied clients' : 'Clients satisfaits' },
    { value: '24h', label: language === 'en' ? 'Response time' : 'Délai d\'intervention' }
  ];

  return (
    <div className="min-h-screen bg-gray-900 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Main About Section - Like section a propos.png */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl p-8 lg:p-12">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left Side - Text */}
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                  {language === 'en' ? 'About GB Mobile' : 'À propos de GB Mobile'}
                </h1>
                <p className="text-lg text-gray-600 mb-8">
                  {language === 'en' 
                    ? 'Your trusted partner for all your mobile mechanic needs in the Lachute region. Professional, honest, and stress-free service.'
                    : 'Votre partenaire de confiance pour tous vos besoins de mécanique mobile dans la région de Lachute. Service professionnel, honnête et sans stress.'
                  }
                </p>
                
                {/* Stats */}
                <div className="grid grid-cols-3 gap-6 mb-8">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="mb-2">
                        <stat.icon className={`h-8 w-8 mx-auto ${stat.iconColor}`} />
                      </div>
                      <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Side - Image */}
              <div className="relative">
                <div className="relative aspect-video rounded-xl overflow-hidden">
                  <Image
                    src="/images/gb-mobile-van.png"
                    alt="GB Mobile Service Van"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                  {/* Google Rating Badge */}
                  <div className="absolute bottom-4 left-4 bg-white rounded-lg px-4 py-2 shadow-lg">
                    <div className="flex items-center gap-2">
                      <Star className="h-5 w-5 text-yellow-500 fill-current" />
                      <span className="font-bold text-gray-900">4.6</span>
                      <span className="text-sm text-gray-600">
                        {language === 'en' ? 'Google Rating' : 'Note Google'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quality Assurance Section - Like a propos section.png */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl p-8 lg:p-12">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                {language === 'en' ? 'Quality Assurance' : 'Assurance qualité'}
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                {language === 'en' 
                  ? 'Quality parts, respected warranties, transparent quotes - your satisfaction is our priority.'
                  : 'Pièces de qualité, garanties respectées, devis transparents - votre satisfaction est notre priorité.'
                }
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
              {qualityAssurances.map((item, index) => (
                <div key={index} className="text-center">
                  <div className="mb-4">
                    <item.icon className={`h-12 w-12 mx-auto ${item.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Reputation Stats - Orange Section */}
            <div className="bg-orange-500 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-white text-center mb-8">
                {language === 'en' ? 'Our Reputation in Numbers' : 'Notre réputation en chiffres'}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {reputationStats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
                    <div className="text-orange-100">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Vision Section - Like a propos.png */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl p-8 lg:p-12">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left Side - Image */}
              <div className="relative aspect-video rounded-xl overflow-hidden">
                <Image
                  src="/images/gb-mobile-van.png"
                  alt="GB Mobile Van"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
              
              {/* Right Side - Text */}
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  {language === 'en' ? 'A Simple Vision: Stress-Free Mechanics' : 'Une vision simple : la mécanique sans stress'}
                </h2>
                <p className="text-gray-600 mb-8">
                  {language === 'en' 
                    ? 'At GB Mobile, we believe that maintaining your vehicle shouldn\'t be a source of stress. That\'s why we developed a mobile service that adapts to your schedule and comes directly to you.'
                    : 'Chez GB Mobile, nous croyons que l\'entretien de votre véhicule ne devrait pas être une source de stress. C\'est pourquoi nous avons développé un service mobile qui s\'adapte à votre horaire et vient directement chez vous.'
                  }
                </p>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {language === 'en' ? 'Expertise That Comes to You' : 'L\'expertise qui se déplace'}
                </h3>
                <p className="text-gray-600">
                  {language === 'en' 
                    ? 'With more than 5 years of experience in the automotive field, our team masters all aspects of modern mechanics. We bring our expertise directly to your home or workplace.'
                    : 'Avec plus de 5 années d\'expérience dans le domaine automobile, notre équipe maîtrise tous les aspects de la mécanique moderne. Nous apportons notre expertise directement à votre domicile ou lieu de travail.'
                  }
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Fundamental Values Section */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl p-8 lg:p-12">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
              {language === 'en' ? 'Our Fundamental Values' : 'Nos valeurs fondamentales'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {fundamentalValues.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="mb-6">
                    <div className="w-16 h-16 mx-auto bg-gray-100 rounded-2xl flex items-center justify-center">
                      <value.icon className={`h-8 w-8 ${value.iconColor}`} />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">
                    {value.title}
                  </h3>
                  <p className="text-gray-600">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our History Section */}
        <section>
          <div className="bg-white rounded-2xl p-8 lg:p-12">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
              {language === 'en' ? 'Our Story' : 'Notre histoire'}
            </h2>
            <p className="text-lg text-gray-600 text-center max-w-4xl mx-auto">
              {language === 'en' 
                ? 'GB Mobile revolutionizes the concept of mechanical service by bringing expertise directly to your home or workplace. Our mission is to offer you an honest, stress-free service, with the same quality as a traditional garage.'
                : 'GB Mobile révolutionne le concept de service mécanique en apportant l\'expertise directement à votre domicile ou lieu de travail. Notre mission est de vous offrir un service honnête, sans stress, avec la même qualité qu\'un garage traditionnel.'
              }
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
