
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Star, 
  Quote, 
  User,
  ThumbsUp,
  MessageCircle
} from 'lucide-react';
import Image from 'next/image';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  service?: string;
  createdAt: string;
}

export default function TestimonialsPage() {
  const { language } = useLanguage();
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    rating: 5,
    comment: '',
    service: ''
  });
  
  const t = (key: string) => getTranslation(language, key);

  // Load testimonials
  useEffect(() => {
    loadTestimonials();
  }, []);

  const loadTestimonials = async () => {
    try {
      const response = await fetch('/api/testimonials');
      if (response.ok) {
        const data = await response.json();
        setTestimonials(data.testimonials || []);
      }
    } catch (error) {
      console.error('Error loading testimonials:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/testimonials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, language })
      });

      if (response.ok) {
        toast.success(language === 'en' ? 'Thank you for your review!' : 'Merci pour votre avis !');
        setFormData({ name: '', email: '', rating: 5, comment: '', service: '' });
        loadTestimonials();
      } else {
        throw new Error('Submission failed');
      }
    } catch (error) {
      toast.error(language === 'en' ? 'Error submitting review. Please try again.' : 'Erreur lors de l\'envoi. Veuillez réessayer.');
    } finally {
      setSubmitting(false);
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-5 w-5 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-400'
        }`}
      />
    ));
  };

  // Mock testimonials for display
  const sampleTestimonials = [
    {
      id: '1',
      name: 'Michel Dubois',
      rating: 5,
      comment: language === 'en' 
        ? 'Excellent service! The mechanic arrived quickly and fixed my brake issue on the spot. Very professional and fair pricing.' 
        : 'Service excellent ! Le mécanicien est arrivé rapidement et a réglé mon problème de freins sur place. Très professionnel et prix équitable.',
      service: language === 'en' ? 'Brake Service' : 'Service de freins',
      createdAt: '2024-08-15'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      rating: 5,
      comment: language === 'en' 
        ? 'GB Mobile saved my day! My car broke down and they came to my workplace within an hour. Great diagnostic service and honest mechanic.'
        : 'GB Mobile m\'a sauvé la journée ! Ma voiture est tombée en panne et ils sont venus à mon lieu de travail en moins d\'une heure. Excellent service de diagnostic et mécanicien honnête.',
      service: language === 'en' ? 'Diagnostics' : 'Diagnostic',
      createdAt: '2024-08-10'
    },
    {
      id: '3',
      name: 'Robert Lavoie',
      rating: 5,
      comment: language === 'en'
        ? 'Fast and reliable oil change service. The convenience of having it done at home is unbeatable. Will definitely use again!'
        : 'Service de changement d\'huile rapide et fiable. La commodité de le faire faire à la maison est imbattable. Je vais certainement utiliser à nouveau !',
      service: language === 'en' ? 'Oil Change' : 'Changement d\'huile',
      createdAt: '2024-07-28'
    }
  ];

  const displayTestimonials = testimonials.length > 0 ? testimonials : sampleTestimonials;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <Image
          src="/images/testimonials-bg.png"
          alt="Testimonials Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Hero Section */}
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-['Inter'] tracking-tight">
              {t('testimonialsTitle')}
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed font-['Inter']">
              {language === 'en' 
                ? 'Read what our satisfied customers have to say about our mobile automotive repair services.'
                : 'Lisez ce que nos clients satisfaits disent de nos services de réparation automobile mobile.'
              }
            </p>
          </div>

          {/* Ratings Summary */}
          <section className="mb-16 animate-slide-up">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl p-8 hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/10">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-3 mb-4">
                    <div className="p-2 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full">
                      <Star className="h-8 w-8 text-white fill-current" />
                    </div>
                    <span className="text-4xl font-bold text-white font-['Inter']">4.6</span>
                    <span className="text-gray-300 text-xl">/5</span>
                  </div>
                  <h3 className="text-white text-2xl font-bold mb-2 font-['Inter'] tracking-tight">
                    {t('googleRating')}
                  </h3>
                  <p className="text-gray-200 font-['Inter']">
                    {language === 'en' 
                      ? 'Based on verified Google reviews'
                      : 'Basé sur des avis Google vérifiés'
                    }
                  </p>
                </div>
              </div>

              <div className="bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl p-8 hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/10">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-3 mb-4">
                    <div className="p-2 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full">
                      <ThumbsUp className="h-8 w-8 text-white" />
                    </div>
                    <span className="text-4xl font-bold text-white font-['Inter']">100%</span>
                  </div>
                  <h3 className="text-white text-2xl font-bold mb-2 font-['Inter'] tracking-tight">
                    {t('facebookRecommended')}
                  </h3>
                  <p className="text-gray-200 font-['Inter']">
                    {language === 'en' 
                      ? 'All Facebook customers recommend our service'
                      : 'Tous nos clients Facebook recommandent notre service'
                    }
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Testimonials Grid */}
          <section className="mb-16 animate-slide-up">
            <h2 className="text-3xl font-bold text-white text-center mb-12 font-['Inter'] tracking-tight">
              {language === 'en' ? 'Customer Reviews' : 'Avis clients'}
            </h2>
            
            {loading ? (
              <div className="text-center text-gray-200 font-['Inter']">
                {t('loading')}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {displayTestimonials.map((testimonial, index) => (
                  <div 
                    key={testimonial.id} 
                    className={`bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl p-6 hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/10 animate-fade-in`}
                    style={{ animationDelay: `${index * 150}ms` }}
                  >
                    {/* Header with user info and rating */}
                    <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full shadow-lg">
                        <User className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-white font-bold text-lg font-['Inter']">{testimonial.name}</h3>
                        <div className="flex items-center gap-1 mt-1">
                          {renderStars(testimonial.rating)}
                        </div>
                      </div>
                    </div>

                    {/* Quote icon and testimonial text */}
                    <div className="mb-6">
                      <Quote className="h-8 w-8 text-[#E50914] mb-4 opacity-60" />
                      <p className="text-gray-200 italic text-lg leading-relaxed font-['Inter']">
                        "{testimonial.comment}"
                      </p>
                    </div>

                    {/* Service tag */}
                    {testimonial.service && (
                      <div className="inline-flex items-center px-3 py-1 bg-[#E50914]/20 border border-[#E50914]/30 rounded-full">
                        <span className="text-[#E50914] text-sm font-medium font-['Inter']">
                          {language === 'en' ? 'Service:' : 'Service :'} {testimonial.service}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Review Form */}
          <section className="animate-slide-up">
            <div className="bg-gray-800/40 backdrop-blur-lg border border-gray-600/30 rounded-2xl p-8 shadow-2xl hover:shadow-red-500/10 transition-all duration-300">
              <div className="text-center mb-8">
                <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-[#E50914] to-[#B8070F] rounded-full w-fit shadow-lg">
                  <MessageCircle className="h-10 w-10 text-white" />
                </div>
                <h2 className="text-white text-3xl font-bold font-['Inter'] tracking-tight">
                  {t('leaveReview')}
                </h2>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name" className="text-white font-medium font-['Inter']">
                      {t('name')} *
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      className="mt-2 bg-gray-700/50 backdrop-blur border-gray-500/50 text-white placeholder-gray-400 rounded-xl focus:border-[#E50914] focus:ring-[#E50914] transition-all duration-200 font-['Inter']"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-white font-medium font-['Inter']">
                      {t('email')} ({t('optional')})
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="mt-2 bg-gray-700/50 backdrop-blur border-gray-500/50 text-white placeholder-gray-400 rounded-xl focus:border-[#E50914] focus:ring-[#E50914] transition-all duration-200 font-['Inter']"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-white font-medium font-['Inter']">{t('rating')} *</Label>
                  <div className="flex items-center gap-3 mt-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-10 w-10 cursor-pointer transition-all duration-200 ${
                          star <= formData.rating
                            ? 'text-yellow-400 fill-current transform scale-110'
                            : 'text-gray-400 hover:text-yellow-300 hover:scale-105'
                        }`}
                        onClick={() => setFormData({ ...formData, rating: star })}
                      />
                    ))}
                    <span className="text-white ml-4 text-lg font-medium font-['Inter']">{formData.rating}/5</span>
                  </div>
                </div>

                <div>
                  <Label htmlFor="service" className="text-white font-medium font-['Inter']">
                    {t('service')} ({t('optional')})
                  </Label>
                  <Input
                    id="service"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    placeholder={language === 'en' ? 'e.g., Oil Change, Brake Service' : 'ex: Changement d\'huile, Service de freins'}
                    className="mt-2 bg-gray-700/50 backdrop-blur border-gray-500/50 text-white placeholder-gray-400 rounded-xl focus:border-[#E50914] focus:ring-[#E50914] transition-all duration-200 font-['Inter']"
                  />
                </div>

                <div>
                  <Label htmlFor="comment" className="text-white font-medium font-['Inter']">
                    {t('comment')} *
                  </Label>
                  <Textarea
                    id="comment"
                    value={formData.comment}
                    onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                    required
                    rows={5}
                    className="mt-2 bg-gray-700/50 backdrop-blur border-gray-500/50 text-white placeholder-gray-400 rounded-xl resize-none focus:border-[#E50914] focus:ring-[#E50914] transition-all duration-200 font-['Inter']"
                    placeholder={language === 'en' 
                      ? 'Tell us about your experience...'
                      : 'Parlez-nous de votre expérience...'
                    }
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={submitting}
                  className="w-full bg-gradient-to-r from-[#E50914] to-[#B8070F] hover:from-[#B8070F] hover:to-[#E50914] text-white font-bold py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/25 font-['Inter'] text-lg"
                >
                  {submitting ? t('loading') : t('submit')}
                </Button>
              </form>
            </div>
          </section>
        </div>
      </div>

      {/* Animation Styles */}
      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slide-up {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
        
        .animate-slide-up {
          animation: slide-up 1s ease-out;
        }
      `}</style>
    </div>
  );
}
