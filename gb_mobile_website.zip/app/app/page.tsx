
'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  DollarSign, 
  Shield, 
  Star, 
  ThumbsUp, 
  Wrench, 
  Car,
  Phone,
  MapPin
} from 'lucide-react';
import { getTranslation } from '@/lib/i18n';
import { useLanguage } from '@/contexts/LanguageContext';

export default function HomePage() {
  const { language } = useLanguage();
  const t = (key: string) => getTranslation(language, key);

  const keyPoints = [
    {
      icon: Clock,
      title: t('key24h'),
      description: language === 'en' ? 'Available 24/7 for emergency repairs' : 'Disponible 24h/24 et 7j/7 pour les réparations d\'urgence'
    },
    {
      icon: DollarSign,
      title: t('keyTransparent'),
      description: language === 'en' ? 'Clear, upfront pricing with no hidden fees' : 'Prix clairs et transparents sans frais cachés'
    },
    {
      icon: Shield,
      title: t('keyGuaranteed'),
      description: language === 'en' ? 'All work comes with our quality guarantee' : 'Tous nos travaux sont garantis'
    }
  ];

  const services = [
    {
      title: t('oilChange'),
      price: '$90 CAD',
      icon: Car,
      description: t('oilChangeDesc')
    },
    {
      title: t('tireChange'),
      price: '$60-100 CAD',
      icon: Car,
      description: t('tireChangeDesc')
    },
    {
      title: t('brakeService'),
      price: '$135 CAD',
      icon: Wrench,
      description: t('brakeServiceDesc')
    },
    {
      title: t('diagnostics'),
      price: '$90 CAD',
      icon: Wrench,
      description: t('diagnosticsDesc')
    }
  ];

  // Removed the mounted check to fix display issue

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 overflow-hidden min-h-screen">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image
            src="/landing-bg.png"
            alt="Professional automotive garage background"
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
        </div>
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-black/60" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 h-full flex flex-col justify-center">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center w-full mb-12">
            
            {/* Left Content */}
            <div className="space-y-6 animate-fade-in-up">
              {/* Service Badge */}
              <div className="inline-flex items-center gap-2 bg-orange-500 px-4 py-2 rounded-full text-white font-medium animate-pulse-subtle">
                <Clock className="h-4 w-4" />
                {language === 'en' ? 'Service available 24/7' : 'Service disponible 24h/24'}
              </div>
              
              {/* Main Title */}
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight animate-slide-down">
                  {language === 'en' 
                    ? 'Mobile Mechanic in Lachute' 
                    : 'Mécanique mobile à Lachute'
                  }
                </h1>
                
                <h2 className="text-2xl lg:text-3xl font-semibold text-orange-400 animate-fade-in-delayed">
                  {language === 'en'
                    ? 'Maintenance and repairs where you are'
                    : 'Entretien et réparations là où vous êtes'
                  }
                </h2>
                
                <p className="text-lg text-gray-200 max-w-xl leading-relaxed animate-fade-in-delayed">
                  {language === 'en'
                    ? 'Professional mechanic service that comes to your home or office. Guaranteed work, transparent pricing.'
                    : 'Service de mécanique professionnel qui se déplace à domicile ou au bureau. Travail garanti, prix transparents.'
                  }
                </p>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up">
                <Button 
                  asChild
                  size="lg"
                  className="btn-interactive bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 text-lg font-semibold"
                >
                  <a href="tel:450-613-3778" className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    {language === 'en' ? 'Call Now' : 'Appeler maintenant'}
                  </a>
                </Button>
                <Button 
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white bg-white text-black hover:bg-gray-100 px-8 py-4 text-lg font-semibold btn-interactive"
                >
                  <Link href="/contact">
                    {t('bookNow')}
                  </Link>
                </Button>
              </div>
            </div>

            {/* Right Content - Services Box */}
            <div className="lg:justify-self-end animate-fade-in-up">
              <div className="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-600 max-w-md">
                <h3 className="text-xl font-semibold text-white mb-6">
                  {language === 'en' ? 'Popular Services' : 'Services populaires'}
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>{language === 'en' ? 'Mobile oil change' : 'Vidange d\'huile mobile'}</span>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>{language === 'en' ? 'Tire change' : 'Changement de pneus'}</span>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>{language === 'en' ? 'Electronic diagnostics' : 'Diagnostic électronique'}</span>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>{language === 'en' ? 'Brake service' : 'Service de freins'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Stats - No longer absolute positioned */}
          <div className="w-full animate-fade-in-delayed">
            <div className="flex flex-wrap justify-center lg:justify-start gap-6 lg:gap-12">
              <div className="text-center lg:text-left">
                <div className="text-2xl lg:text-3xl font-bold text-orange-400">4.6/5</div>
                <div className="text-white text-sm">Google Reviews</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl lg:text-3xl font-bold text-orange-400">100%</div>
                <div className="text-white text-sm">
                  {language === 'en' ? 'Recommended Facebook' : 'Recommandé Facebook'}
                </div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl lg:text-3xl font-bold text-orange-400">24h</div>
                <div className="text-white text-sm">
                  {language === 'en' ? 'Fast Service' : 'Service rapide'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Points - Redesigned */}
      <section className="relative py-20 overflow-hidden">
        {/* Background with overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700"></div>
        
        {/* Horizontal overlay lines */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent"></div>
        
        {/* Diagonal overlay elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-orange-500/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {keyPoints.map((point, index) => (
              <div key={index} 
                   className="group relative bg-gray-800/80 backdrop-blur-sm border border-gray-600/50 rounded-2xl p-8 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-2xl animate-fade-in-stagger"
                   style={{animationDelay: `${index * 0.2}s`}}
              >
                {/* Hover glow effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="relative z-10">
                  <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-red-600 to-red-700 rounded-full w-fit group-hover:from-red-500 group-hover:to-orange-500 transition-all duration-500 shadow-lg group-hover:shadow-red-500/25">
                    <point.icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-white text-2xl font-bold mb-4 group-hover:text-red-200 transition-colors duration-300">
                    {point.title}
                  </h3>
                  <p className="text-gray-300 group-hover:text-gray-200 transition-colors duration-300 leading-relaxed">
                    {point.description}
                  </p>
                </div>
                
                {/* Corner accent */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-red-500/30 to-transparent rounded-bl-full rounded-tr-2xl"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview - Redesigned */}
      <section className="relative py-24 overflow-hidden">
        {/* Enhanced background */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-gray-700 to-gray-800"></div>
        
        {/* Multiple overlay elements */}
        <div className="absolute top-0 left-1/4 w-full h-px bg-gradient-to-r from-transparent via-orange-400 to-transparent"></div>
        <div className="absolute bottom-0 right-1/4 w-full h-px bg-gradient-to-r from-transparent via-red-400 to-transparent"></div>
        
        {/* Floating geometric overlays */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl"></div>
        <div className="absolute top-32 right-20 w-40 h-40 bg-red-500/5 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 left-1/3 w-36 h-36 bg-orange-500/8 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-28 h-28 bg-red-500/8 rounded-full blur-2xl"></div>
        
        {/* Side gradient overlays */}
        <div className="absolute left-0 top-0 w-48 h-full bg-gradient-to-r from-red-500/5 to-transparent"></div>
        <div className="absolute right-0 top-0 w-48 h-full bg-gradient-to-l from-orange-500/5 to-transparent"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500/20 to-orange-500/20 px-6 py-2 rounded-full text-orange-300 font-medium mb-6 backdrop-blur-sm border border-orange-500/30">
              <Wrench className="h-4 w-4" />
              {language === 'en' ? 'Our Services' : 'Nos Services'}
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              {t('services')}
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              {language === 'en' 
                ? 'Professional automotive services at your location'
                : 'Services automobiles professionnels à votre emplacement'
              }
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} 
                   className="group relative bg-gray-800/60 backdrop-blur-lg border border-gray-600/40 rounded-2xl p-6 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-2xl animate-fade-in-stagger"
                   style={{animationDelay: `${index * 0.15}s`}}
              >
                {/* Animated background on hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 via-transparent to-orange-500/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
                
                {/* Glowing border on hover */}
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" 
                     style={{boxShadow: '0 0 30px rgba(239, 68, 68, 0.3)'}}></div>
                
                <div className="relative z-10">
                  {/* Icon with enhanced styling */}
                  <div className="mx-auto mb-6 p-4 bg-gradient-to-br from-red-600 via-red-500 to-orange-500 rounded-2xl w-fit group-hover:from-red-500 group-hover:to-orange-400 transition-all duration-500 shadow-lg group-hover:shadow-red-500/40">
                    <service.icon className="h-8 w-8 text-white" />
                  </div>
                  
                  {/* Service Title */}
                  <h3 className="text-white text-xl font-bold mb-3 group-hover:text-red-200 transition-colors duration-300">
                    {service.title}
                  </h3>
                  
                  {/* Price Badge */}
                  <div className="inline-flex items-center px-4 py-2 bg-red-500/20 border border-red-500/40 rounded-full text-red-300 font-semibold text-sm mb-4 group-hover:bg-red-500/30 group-hover:border-red-400/60 transition-all duration-300">
                    {service.price}
                  </div>
                  
                  {/* Description */}
                  <p className="text-gray-400 text-sm mb-6 group-hover:text-gray-300 transition-colors duration-300 leading-relaxed">
                    {service.description}
                  </p>
                  
                  {/* CTA Button */}
                  <Button 
                    asChild
                    size="sm"
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-orange-500 text-white border-0 transition-all duration-300 shadow-lg group-hover:shadow-red-500/25"
                  >
                    <Link href="/contact" className="flex items-center justify-center gap-2">
                      {t('bookNow')}
                    </Link>
                  </Button>
                </div>
                
                {/* Decorative corner elements */}
                <div className="absolute top-0 left-0 w-16 h-16 bg-gradient-to-br from-orange-500/20 to-transparent rounded-tl-2xl rounded-br-full"></div>
                <div className="absolute bottom-0 right-0 w-12 h-12 bg-gradient-to-tl from-red-500/20 to-transparent rounded-br-2xl rounded-tl-full"></div>
              </div>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="text-center mt-16">
            <Button asChild size="lg" 
                    className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white border-0 px-8 py-4 text-lg font-semibold transition-all duration-300 shadow-xl hover:shadow-red-500/25 animate-fade-in-up">
              <Link href="/services" className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                {language === 'en' ? 'View All Services' : 'Voir tous les services'}
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Service Area */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-6 animate-fade-in-up">
            <MapPin className="h-8 w-8 text-red-600 animate-bounce-subtle" />
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              {t('serviceAreaTitle')}
            </h2>
          </div>
          <p className="text-xl text-gray-300 mb-8 animate-fade-in-delayed">
            {language === 'en' 
              ? 'Serving Lachute, Mirabel, Saint-Jérôme, Brownsburg-Chatham, Grenville, and surrounding areas'
              : 'Desservant Lachute, Mirabel, Saint-Jérôme, Brownsburg-Chatham, Grenville et les environs'
            }
          </p>
          <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-white btn-interactive animate-button-pulse animate-fade-in-up">
            <Link href="/service-area">
              {language === 'en' ? 'View Coverage Map' : 'Voir la carte de couverture'}
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
