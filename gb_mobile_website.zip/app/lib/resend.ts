
import { Resend } from 'resend'

if (!process.env.RESEND_API_KEY) {
  throw new Error('RESEND_API_KEY is not defined')
}

export const resend = new Resend(process.env.RESEND_API_KEY)

export const sendContactEmail = async (data: {
  name: string
  email: string
  phone?: string
  message: string
  language: 'fr' | 'en'
}) => {
  const { name, email, phone, message, language } = data

  const subject = language === 'fr' 
    ? `Nouveau message de contact de ${name}`
    : `New contact message from ${name}`

  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a1a1a; padding: 20px; border-radius: 10px 10px 0 0;">
        <h1 style="color: #dc2626; margin: 0; font-size: 24px;">
          ${language === 'fr' ? 'Nouveau message de contact' : 'New Contact Message'}
        </h1>
      </div>
      <div style="background-color: #f5f5f5; padding: 30px; border-radius: 0 0 10px 10px;">
        <div style="background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h2 style="color: #1a1a1a; margin-top: 0;">
            ${language === 'fr' ? 'Détails du contact' : 'Contact Details'}
          </h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568; width: 120px;">
                ${language === 'fr' ? 'Nom :' : 'Name:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${name}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Email :' : 'Email:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">
                <a href="mailto:${email}" style="color: #dc2626; text-decoration: none;">${email}</a>
              </td>
            </tr>
            ${phone ? `
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Téléphone :' : 'Phone:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">
                <a href="tel:${phone}" style="color: #dc2626; text-decoration: none;">${phone}</a>
              </td>
            </tr>
            ` : ''}
          </table>
          
          <h3 style="color: #1a1a1a; margin-top: 30px; margin-bottom: 15px;">
            ${language === 'fr' ? 'Message :' : 'Message:'}
          </h3>
          <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; border-left: 4px solid #dc2626;">
            <p style="margin: 0; line-height: 1.5; color: #1a1a1a;">${message}</p>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px;">
          ${language === 'fr' 
            ? 'Ce message a été envoyé depuis le formulaire de contact du site web GB Mobile' 
            : 'This message was sent from the GB Mobile website contact form'
          }
        </div>
      </div>
    </div>
  `

  try {
    // Prepare recipient list
    const recipients = [process.env.TO_EMAIL!]
    if (process.env.TO_EMAIL_SECONDARY) {
      recipients.push(process.env.TO_EMAIL_SECONDARY)
    }

    const result = await resend.emails.send({
      from: process.env.FROM_EMAIL!,
      to: recipients,
      subject,
      html: htmlContent,
      replyTo: email
    })

    return { success: true, data: result }
  } catch (error) {
    console.error('Error sending email:', error)
    return { success: false, error }
  }
}

export const sendBookingEmail = async (data: {
  name: string
  email: string
  phone: string
  service: string
  preferredDate: string
  preferredTime: string
  address: string
  message?: string
  language: 'fr' | 'en'
}) => {
  const { name, email, phone, service, preferredDate, preferredTime, address, message, language } = data

  const subject = language === 'fr'
    ? `Nouvelle demande de réservation de ${name}`
    : `New booking request from ${name}`

  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a1a1a; padding: 20px; border-radius: 10px 10px 0 0;">
        <h1 style="color: #dc2626; margin: 0; font-size: 24px;">
          ${language === 'fr' ? 'Nouvelle demande de réservation' : 'New Booking Request'}
        </h1>
      </div>
      <div style="background-color: #f5f5f5; padding: 30px; border-radius: 0 0 10px 10px;">
        <div style="background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h2 style="color: #1a1a1a; margin-top: 0;">
            ${language === 'fr' ? 'Informations du client' : 'Customer Information'}
          </h2>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568; width: 140px;">
                ${language === 'fr' ? 'Nom :' : 'Name:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${name}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Email :' : 'Email:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">
                <a href="mailto:${email}" style="color: #dc2626; text-decoration: none;">${email}</a>
              </td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Téléphone :' : 'Phone:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">
                <a href="tel:${phone}" style="color: #dc2626; text-decoration: none;">${phone}</a>
              </td>
            </tr>
          </table>

          <h2 style="color: #1a1a1a; margin-top: 0;">
            ${language === 'fr' ? 'Détails du service' : 'Service Details'}
          </h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568; width: 140px;">
                ${language === 'fr' ? 'Service :' : 'Service:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${service}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Date préférée :' : 'Preferred Date:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${preferredDate}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Heure préférée :' : 'Preferred Time:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${preferredTime}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Adresse :' : 'Address:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${address}</td>
            </tr>
          </table>

          ${message ? `
          <h3 style="color: #1a1a1a; margin-top: 30px; margin-bottom: 15px;">
            ${language === 'fr' ? 'Message additionnel :' : 'Additional Message:'}
          </h3>
          <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; border-left: 4px solid #dc2626;">
            <p style="margin: 0; line-height: 1.5; color: #1a1a1a;">${message}</p>
          </div>
          ` : ''}
        </div>

        <div style="text-align: center; margin-top: 20px;">
          <div style="background-color: #dc2626; color: white; padding: 15px; border-radius: 8px;">
            <p style="margin: 0; font-weight: bold;">
              ${language === 'fr' ? '🚗 RÉSERVATION URGENTE - Contactez le client rapidement!' : '🚗 URGENT BOOKING - Contact customer quickly!'}
            </p>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px;">
          ${language === 'fr' 
            ? 'Cette demande a été envoyée depuis le formulaire de réservation du site web GB Mobile' 
            : 'This request was sent from the GB Mobile website booking form'
          }
        </div>
      </div>
    </div>
  `

  try {
    // Prepare recipient list
    const recipients = [process.env.TO_EMAIL!]
    if (process.env.TO_EMAIL_SECONDARY) {
      recipients.push(process.env.TO_EMAIL_SECONDARY)
    }

    const result = await resend.emails.send({
      from: process.env.FROM_EMAIL!,
      to: recipients,
      subject,
      html: htmlContent,
      replyTo: email
    })

    return { success: true, data: result }
  } catch (error) {
    console.error('Error sending booking email:', error)
    return { success: false, error }
  }
}

export const sendTestimonialNotification = async (data: {
  name: string
  email?: string
  rating: number
  comment: string
  language: 'fr' | 'en'
}) => {
  const { name, email, rating, comment, language } = data

  const subject = language === 'fr'
    ? `Nouveau témoignage de ${name} (${rating}/5 étoiles)`
    : `New testimonial from ${name} (${rating}/5 stars)`

  const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating)

  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a1a1a; padding: 20px; border-radius: 10px 10px 0 0;">
        <h1 style="color: #dc2626; margin: 0; font-size: 24px;">
          ${language === 'fr' ? 'Nouveau témoignage client' : 'New Customer Testimonial'}
        </h1>
      </div>
      <div style="background-color: #f5f5f5; padding: 30px; border-radius: 0 0 10px 10px;">
        <div style="background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <div style="text-align: center; margin-bottom: 20px;">
            <div style="font-size: 32px; margin-bottom: 10px;">${stars}</div>
            <div style="font-size: 24px; font-weight: bold; color: #dc2626;">${rating}/5</div>
          </div>

          <h2 style="color: #1a1a1a; margin-top: 0;">
            ${language === 'fr' ? 'Informations du client' : 'Customer Information'}
          </h2>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568; width: 120px;">
                ${language === 'fr' ? 'Nom :' : 'Name:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">${name}</td>
            </tr>
            ${email ? `
            <tr>
              <td style="padding: 8px 0; font-weight: bold; color: #4a5568;">
                ${language === 'fr' ? 'Email :' : 'Email:'}
              </td>
              <td style="padding: 8px 0; color: #1a1a1a;">
                <a href="mailto:${email}" style="color: #dc2626; text-decoration: none;">${email}</a>
              </td>
            </tr>
            ` : ''}
          </table>

          <h3 style="color: #1a1a1a; margin-top: 30px; margin-bottom: 15px;">
            ${language === 'fr' ? 'Commentaire :' : 'Comment:'}
          </h3>
          <div style="background-color: #f8f9fa; padding: 20px; border-radius: 6px; border-left: 4px solid #dc2626;">
            <p style="margin: 0; line-height: 1.6; color: #1a1a1a; font-style: italic;">"${comment}"</p>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px;">
          ${language === 'fr' 
            ? 'Ce témoignage a été laissé sur le site web GB Mobile' 
            : 'This testimonial was left on the GB Mobile website'
          }
        </div>
      </div>
    </div>
  `

  try {
    // Prepare recipient list
    const recipients = [process.env.TO_EMAIL!]
    if (process.env.TO_EMAIL_SECONDARY) {
      recipients.push(process.env.TO_EMAIL_SECONDARY)
    }

    const result = await resend.emails.send({
      from: process.env.FROM_EMAIL!,
      to: recipients,
      subject,
      html: htmlContent,
      replyTo: email || undefined
    })

    return { success: true, data: result }
  } catch (error) {
    console.error('Error sending testimonial notification:', error)
    return { success: false, error }
  }
}
