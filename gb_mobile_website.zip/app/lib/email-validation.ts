
import { z } from 'zod'

// Validation schemas for forms
export const contactFormSchema = z.object({
  name: z
    .string()
    .min(1, 'Name is required')
    .min(2, 'Name must be at least 2 characters'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
  phone: z
    .string()
    .optional()
    .refine((val) => !val || val.length >= 10, {
      message: 'Phone number must be at least 10 digits'
    }),
  message: z
    .string()
    .min(1, 'Message is required')
    .min(3, 'Message must be at least 3 characters')
    .max(1000, 'Message must be less than 1000 characters')
})

export const bookingFormSchema = z.object({
  name: z
    .string()
    .min(1, 'Name is required')
    .min(2, 'Name must be at least 2 characters'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
  phone: z
    .string()
    .min(1, 'Phone number is required')
    .min(10, 'Phone number must be at least 10 digits')
    .regex(/^\+?[\d\s\-\(\)]+$/, 'Please enter a valid phone number'),
  service: z
    .string()
    .min(1, 'Please select a service'),
  preferredDate: z
    .string()
    .min(1, 'Please select a preferred date'),
  preferredTime: z
    .string()
    .min(1, 'Please select a preferred time'),
  address: z
    .string()
    .min(1, 'Address is required')
    .min(10, 'Please provide a complete address'),
  message: z
    .string()
    .optional()
    .refine((val) => !val || val.length <= 500, {
      message: 'Additional message must be less than 500 characters'
    })
})

export const testimonialFormSchema = z.object({
  name: z
    .string()
    .min(1, 'Name is required')
    .min(2, 'Name must be at least 2 characters'),
  email: z
    .string()
    .optional()
    .refine((val) => !val || val === '' || z.string().email().safeParse(val).success, {
      message: 'Please enter a valid email address or leave empty'
    }),
  rating: z
    .number()
    .min(1, 'Please select a rating')
    .max(5, 'Rating cannot exceed 5 stars'),
  comment: z
    .string()
    .min(1, 'Comment is required')
    .min(3, 'Comment must be at least 3 characters')
    .max(500, 'Comment must be less than 500 characters')
})

// Types
export type ContactFormData = z.infer<typeof contactFormSchema>
export type BookingFormData = z.infer<typeof bookingFormSchema>
export type TestimonialFormData = z.infer<typeof testimonialFormSchema>

// Validation functions
export function validateContactForm(data: any): { success: boolean; data?: ContactFormData; errors?: any } {
  const result = contactFormSchema.safeParse(data)
  if (result.success) {
    return { success: true, data: result.data }
  }
  return { success: false, errors: result.error.flatten().fieldErrors }
}

export function validateBookingForm(data: any): { success: boolean; data?: BookingFormData; errors?: any } {
  const result = bookingFormSchema.safeParse(data)
  if (result.success) {
    return { success: true, data: result.data }
  }
  return { success: false, errors: result.error.flatten().fieldErrors }
}

export function validateTestimonialForm(data: any): { success: boolean; data?: TestimonialFormData; errors?: any } {
  const result = testimonialFormSchema.safeParse(data)
  if (result.success) {
    return { success: true, data: result.data }
  }
  return { success: false, errors: result.error.flatten().fieldErrors }
}
