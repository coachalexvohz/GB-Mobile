
import type { Language } from '@/contexts/LanguageContext';

export type { Language };

export const translations = {
  en: {
    // Navigation
    home: 'Home',
    about: 'About',
    services: 'Services',
    serviceArea: 'Service Area',
    testimonials: 'Testimonials',
    contact: 'Contact',
    bookNow: 'Book Now',
    callNow: 'Call Now',
    
    // Home Page
    heroTitle: 'Professional Mobile Automotive Repair',
    heroSubtitle: 'Expert mechanic service at your location - 24/7 emergency repairs',
    tagline: 'Quality automotive repair comes to you',
    key24h: '24h Emergency Service',
    keyTransparent: 'Transparent Pricing',
    keyGuaranteed: 'Guaranteed Work',
    googleRating: 'Google Rating',
    facebookRecommended: '100% Recommended on Facebook',
    
    // Services
    oilChange: 'Oil Change',
    oilChangeDesc: 'Complete oil and filter change service at your location',
    tireChange: 'Tire Change',
    tireChangeDesc: 'Seasonal tire mounting, balancing, and storage',
    brakeService: 'Brake Service',
    brakeServiceDesc: 'Complete brake system inspection, repair, and maintenance',
    diagnostics: 'Diagnostics',
    diagnosticsDesc: 'Professional automotive diagnostics and troubleshooting',
    carElectricalService: 'Car Electrical Service',
    carElectricalServiceDesc: 'Complete electrical system diagnosis and repair',
    batteryService: 'Battery Service',
    batteryServiceDesc: 'Battery testing, replacement, and electrical charging system service',
    exhaustMufflerService: 'Exhaust & Muffler Service',
    exhaustMufflerServiceDesc: 'Exhaust system repair, muffler replacement, and emissions service',
    suspensionSteering: 'Suspension & Steering',
    suspensionSteeringDesc: 'Suspension repair, steering alignment, and handling optimization',
    price: 'Starting at',
    
    // About
    aboutTitle: 'About GB Mobile',
    aboutMission: 'Professional mobile automotive repair service serving Lachute and surrounding areas since 2021.',
    experience: '10+ Years Experience',
    certified: 'Certified in Quebec',
    aboutText: 'Our certified automotive mechanic brings over 10 years of experience directly to your location. We specialize in mobile repair, brake systems, diagnostics, and general maintenance.',
    
    // Contact
    contactTitle: 'Contact & Booking',
    contactInfo: 'Contact Information',
    primaryPhone: 'Primary',
    secondaryPhone: 'Secondary',
    email: 'Email',
    contactForm: 'Contact Form',
    bookingForm: 'Book Service',
    name: 'Name',
    phone: 'Phone',
    service: 'Service',
    message: 'Message',
    preferredDate: 'Preferred Date',
    preferredTime: 'Preferred Time',
    location: 'Location',
    vehicleInfo: 'Vehicle Information',
    additionalNotes: 'Additional Notes',
    submit: 'Submit',
    
    // Service Areas
    serviceAreaTitle: 'Service Areas',
    primaryArea: 'Primary Service Area',
    coverageAreas: 'We also serve',
    emergencyAvailable: '24h emergency interventions available',
    
    // Testimonials
    testimonialsTitle: 'Customer Testimonials',
    leaveReview: 'Leave a Review',
    rating: 'Rating',
    comment: 'Comment',
    
    // Our Commitments
    ourCommitments: 'Our Commitments',
    ourCommitmentsSubtitle: 'Three guarantees that make the difference in our mobile mechanic service',
    fastService: 'Fast Service',
    fastServiceDesc: 'Intervention within 24h in the Lachute region',
    guaranteedWork: 'Guaranteed Work',
    guaranteedWorkDesc: 'Guarantee on all our repairs and parts',
    transparentPricing: 'Transparent Pricing',
    transparentPricingDesc: 'Clear quote before intervention, no surprises',
    
    // How it Works
    howItWorks: 'How it Works',
    howItWorksSubtitle: 'A simple and transparent process for your mobile mechanic service',
    step1Contact: 'Contact',
    step1ContactDesc: 'Call us or fill out our form',
    step2Travel: 'Travel',
    step2TravelDesc: 'We come to you with our tools',
    step3Repair: 'Repair',
    step3RepairDesc: 'Professional work and billing',

    // Submissions Form
    submissionsTitle: 'Quote Request',
    vehicleInformation: 'Vehicle Information',
    vehicleMake: 'Vehicle Make',
    vehicleModel: 'Vehicle Model',
    vehicleYear: 'Vehicle Year',
    mileage: 'Mileage',
    engineType: 'Engine Type',
    transmission: 'Transmission',
    observedSymptoms: 'Observed Symptoms',
    problemSince: 'Since When the Problem is Present',
    problemDescription: 'Problem Encountered',
    fullName: 'Full Name',
    phoneNumber: 'Phone Number',
    emailAddress: 'Email Address',
    sendButton: 'Send',
    // Engine Types
    gasoline: 'Gasoline',
    diesel: 'Diesel',
    hybrid: 'Hybrid',
    electric: 'Electric',
    // Transmission Types
    manual: 'Manual',
    automatic: 'Automatic',
    
    // Appointments Form
    appointmentsTitle: 'Schedule an Appointment',
    
    // Site Note
    siteNote: 'All quote requests and appointments must be submitted through this website. We no longer accept requests via text messages to ensure better tracking and more efficient management.',

    // Common
    loading: 'Loading...',
    success: 'Success!',
    error: 'Error',
    required: 'Required',
    optional: 'Optional'
  },
  fr: {
    // Navigation
    home: 'Accueil',
    about: 'À Propos',
    services: 'Services',
    serviceArea: 'Zone de Service',
    testimonials: 'Témoignages',
    contact: 'Contact',
    bookNow: 'Réserver',
    callNow: 'Appeler',
    
    // Home Page
    heroTitle: 'Service de Mécanique Mobile Professionnel',
    heroSubtitle: 'Service de mécanicien expert à votre emplacement - réparations d\'urgence 24/7',
    tagline: 'Un service de mécanique automobile de qualité qui vient à vous',
    key24h: 'Service d\'urgence 24h',
    keyTransparent: 'Prix transparents',
    keyGuaranteed: 'Travail garanti',
    googleRating: 'Note Google',
    facebookRecommended: '100% recommandé sur Facebook',
    
    // Services
    oilChange: 'Changement d\'huile',
    oilChangeDesc: 'Service complet de changement d\'huile et filtre à votre emplacement',
    tireChange: 'Changement de pneus',
    tireChangeDesc: 'Montage saisonnier, équilibrage et entreposage de pneus',
    brakeService: 'Entretien des freins',
    brakeServiceDesc: 'Inspection complète, réparation et entretien des freins',
    diagnostics: 'Diagnostic automobile',
    carElectricalService: 'Service électrique automobile',
    carElectricalServiceDesc: 'Diagnostic et réparation complète du système électrique',
    batteryService: 'Service de batterie',
    batteryServiceDesc: 'Test de batterie, remplacement et service du système de charge électrique',
    exhaustMufflerService: 'Service d\'échappement et silencieux',
    exhaustMufflerServiceDesc: 'Réparation du système d\'échappement, remplacement de silencieux et service d\'émissions',
    suspensionSteering: 'Suspension et direction',
    suspensionSteeringDesc: 'Réparation de suspension, alignement de direction et optimisation de la tenue de route',
    diagnosticsDesc: 'Diagnostic automobile professionnel et dépannage',
    price: 'À partir de',
    
    // About
    aboutTitle: 'À propos de GB Mobile',
    aboutMission: 'Service de mécanique mobile professionnel desservant Lachute et les environs depuis 2021.',
    experience: '10+ années d\'expérience',
    certified: 'Certifié au Québec',
    aboutText: 'Notre mécanicien automobile certifié apporte plus de 10 ans d\'expérience directement à votre emplacement. Nous nous spécialisons dans la réparation mobile, les systèmes de freins, le diagnostic et l\'entretien général.',
    
    // Contact
    contactTitle: 'Contact et Réservation',
    contactInfo: 'Informations de contact',
    primaryPhone: 'Principal',
    secondaryPhone: 'Secondaire',
    email: 'Courriel',
    contactForm: 'Formulaire de contact',
    bookingForm: 'Réserver un service',
    name: 'Nom',
    phone: 'Téléphone',
    service: 'Service',
    message: 'Message',
    preferredDate: 'Date préférée',
    preferredTime: 'Heure préférée',
    location: 'Emplacement',
    vehicleInfo: 'Informations du véhicule',
    additionalNotes: 'Notes additionnelles',
    submit: 'Soumettre',
    
    // Service Areas
    serviceAreaTitle: 'Zones de service',
    primaryArea: 'Zone de service principale',
    coverageAreas: 'Nous desservons aussi',
    emergencyAvailable: 'Interventions d\'urgence 24h disponibles',
    
    // Testimonials
    testimonialsTitle: 'Témoignages de clients',
    leaveReview: 'Laisser un avis',
    rating: 'Note',
    comment: 'Commentaire',
    
    // Our Commitments
    ourCommitments: 'Nos engagements',
    ourCommitmentsSubtitle: 'Trois garanties qui font la différence dans notre service de mécanique mobile',
    fastService: 'Déplacement rapide',
    fastServiceDesc: 'Intervention sous 24h dans la région de Lachute',
    guaranteedWork: 'Travail garanti',
    guaranteedWorkDesc: 'Garantie sur toutes nos réparations et pièces',
    transparentPricing: 'Prix transparents',
    transparentPricingDesc: 'Devis clair avant intervention, sans surprise',
    
    // How it Works
    howItWorks: 'Comment ça marche',
    howItWorksSubtitle: 'Un processus simple et transparent pour votre service de mécanique mobile',
    step1Contact: 'Contact',
    step1ContactDesc: 'Appelez-nous ou remplissez notre formulaire',
    step2Travel: 'Déplacement',
    step2TravelDesc: 'Nous venons chez vous avec nos outils',
    step3Repair: 'Réparation',
    step3RepairDesc: 'Travail professionnel et facturation',

    // Submissions Form
    submissionsTitle: 'Demande de soumission',
    vehicleInformation: 'Informations sur le véhicule',
    vehicleMake: 'Marque du véhicule',
    vehicleModel: 'Modèle du véhicule',
    vehicleYear: 'Année du véhicule',
    mileage: 'Kilométrage',
    engineType: 'Type de moteur',
    transmission: 'Transmission',
    observedSymptoms: 'Symptômes observés',
    problemSince: 'Depuis quand le problème est présent',
    problemDescription: 'Problème rencontré',
    fullName: 'Nom et prénom',
    phoneNumber: 'Numéro de téléphone',
    emailAddress: 'Adresse courriel',
    sendButton: 'Envoyer',
    // Engine Types
    gasoline: 'Essence',
    diesel: 'Diesel',
    hybrid: 'Hybride',
    electric: 'Électrique',
    // Transmission Types
    manual: 'Manuelle',
    automatic: 'Automatique',
    
    // Appointments Form
    appointmentsTitle: 'Prendre un rendez-vous',
    
    // Site Note
    siteNote: 'Toutes les demandes de devis et de rendez-vous doivent être soumises via ce site web. Nous n\'acceptons plus les demandes par messages texte afin d\'assurer un meilleur suivi et une gestion plus efficace.',

    // Common
    loading: 'Chargement...',
    success: 'Succès!',
    error: 'Erreur',
    required: 'Requis',
    optional: 'Optionnel'
  }
};

export const getTranslation = (language: Language, key: string): string => {
  return translations[language]?.[key as keyof typeof translations[typeof language]] || key;
};
