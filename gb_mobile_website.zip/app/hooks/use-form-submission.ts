
import { useState } from 'react'
import { toast } from 'react-hot-toast'

interface FormSubmissionOptions {
  endpoint: string
  successMessage?: {
    fr: string
    en: string
  }
  errorMessage?: {
    fr: string
    en: string
  }
  onSuccess?: () => void
  language?: 'fr' | 'en'
}

export function useFormSubmission({
  endpoint,
  successMessage,
  errorMessage,
  onSuccess,
  language = 'fr'
}: FormSubmissionOptions) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const submitForm = async (data: any) => {
    setIsSubmitting(true)
    
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...data, language }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.message || 'Submission failed')
      }

      // Show success message
      const message = successMessage 
        ? successMessage[language]
        : result.message || (language === 'fr' ? 'Envoyé avec succès!' : 'Sent successfully!')
      
      toast.success(message, {
        duration: 5000,
        position: 'top-center',
        style: {
          background: '#22c55e',
          color: 'white',
          fontWeight: '500',
        },
      })

      // Call onSuccess callback if provided
      onSuccess?.()

      return { success: true, data: result }
    } catch (error: any) {
      console.error('Form submission error:', error)
      
      // Show error message
      const message = errorMessage 
        ? errorMessage[language]
        : error.message || (language === 'fr' ? 'Erreur lors de l\'envoi' : 'Failed to send')
      
      toast.error(message, {
        duration: 5000,
        position: 'top-center',
        style: {
          background: '#ef4444',
          color: 'white',
          fontWeight: '500',
        },
      })

      return { success: false, error }
    } finally {
      setIsSubmitting(false)
    }
  }

  return { submitForm, isSubmitting }
}

// Specific hooks for each form type
export function useContactForm(language: 'fr' | 'en' = 'fr') {
  return useFormSubmission({
    endpoint: '/api/contact',
    successMessage: {
      fr: 'Votre message a été envoyé avec succès! Nous vous répondrons dans les plus brefs délais.',
      en: 'Your message has been sent successfully! We will get back to you as soon as possible.'
    },
    errorMessage: {
      fr: 'Erreur lors de l\'envoi du message. Veuillez réessayer.',
      en: 'Error sending message. Please try again.'
    },
    language
  })
}

export function useBookingForm(language: 'fr' | 'en' = 'fr', onSuccess?: () => void) {
  return useFormSubmission({
    endpoint: '/api/booking',
    successMessage: {
      fr: 'Votre demande de réservation a été envoyée avec succès! Nous vous contacterons dans les plus brefs délais pour confirmer votre rendez-vous.',
      en: 'Your booking request has been sent successfully! We will contact you as soon as possible to confirm your appointment.'
    },
    errorMessage: {
      fr: 'Erreur lors de l\'envoi de la réservation. Veuillez réessayer.',
      en: 'Error sending booking request. Please try again.'
    },
    onSuccess,
    language
  })
}

export function useTestimonialForm(language: 'fr' | 'en' = 'fr', onSuccess?: () => void) {
  return useFormSubmission({
    endpoint: '/api/testimonials',
    successMessage: {
      fr: 'Merci pour votre témoignage! Il sera examiné et publié sur notre site.',
      en: 'Thank you for your testimonial! It will be reviewed and published on our site.'
    },
    errorMessage: {
      fr: 'Erreur lors de l\'envoi du témoignage. Veuillez réessayer.',
      en: 'Error sending testimonial. Please try again.'
    },
    onSuccess,
    language
  })
}
